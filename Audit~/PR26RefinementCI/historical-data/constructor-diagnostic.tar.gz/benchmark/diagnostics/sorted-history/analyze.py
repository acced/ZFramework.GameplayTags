#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,statistics,math,importlib.util
ROOT=Path(__file__).resolve().parent;BENCH=ROOT.parents[1]
spec=importlib.util.spec_from_file_location('frozen_analyze',BENCH/'analyze.py');common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
req=common.require;sha=common.sha;median=statistics.median
TARGET='builder/cluster/4096/build/sorted/same/0'
FROZEN_ROWS={x['id']:x for x in json.loads((BENCH/'results/final-builder-nohw/r0-Dense-A.json').read_text())['rows']}
HASHES={'baseline':'1dd0309a59eb38834eed5da8edfd4e959d9b584457976ed5c69d61fcc2a4d834','selected':'1c032a39cf571ba4ef80ff22c12dd99049b01e1ce0a2cd34040868d899188fa3'}
def verify_identity(ident,variant):
 req(ident['runtime_dll_sha256']==HASHES[variant],'Unexpected Runtime')
 req(ident['facade_dll_sha256']=='de451e90cbba4d9a2ffba95b7a1b0dd319b2ca6f8ec94941f16e78d430f95a51','Unexpected facade')
 req(sha(Path(ident['dll']))==ident['dll_sha256'],'Host DLL changed')
 req(sha(Path(ident['runtime_dll']))==ident['runtime_dll_sha256'],'Runtime changed')
 for f,h in {**ident['source_sha256'],**ident['dependency_sha256']}.items():req(sha(Path(f))==h,'Compiled source/dependency changed')
 for name in ['admitted_build_binding','admitted_source_manifest']:
  x=ident[name];req(sha(Path(x['path']))==x['sha256'],'Compiler binding file changed')
 binding=json.loads(Path(ident['admitted_build_binding']['path']).read_text());source=json.loads(Path(ident['admitted_source_manifest']['path']).read_text())
 req(binding['runtime_sha256']==ident['runtime_dll_sha256'],'Compiler DLL identity')
 req(str(Path(binding['source'])/'Runtime')==ident['snapshot'],'Compiler root identity')
 req(all(ident['source_sha256'].get(f)==source[f] for f in binding['runtime_sources']),'Compiler source inventory')
def check_process(data,meta,ident,counts):
 req(data['caller']==meta['caller'] and data['history']==meta['history'],'Caller/history mismatch')
 req(data['runtime_assembly_sha256']==ident['runtime_dll_sha256'],'Loaded Runtime hash')
 req(Path(data['runtime_assembly_path']).resolve()==(Path(ident['dll']).parent/'GameplayTags.dll').resolve(),'Loaded Runtime path')
 req(data['layout']=='Dense' and data['target_id']==TARGET and data['target_iterations']==973,'Target mismatch')
 req(data['prefix_rows']==(22 if data['history']=='prefix' else 0),'Prefix size mismatch')
 req(not data['vector_accelerated'] and not data['avx2'] and data['hw_intrinsic']=='0','Disabled hardware violated')
 req(all(data[k]=='0' for k in ['tiered_compilation','tiered_pgo','gc_concurrent','ready_to_run']),'Runtime flags')
 req(data['gc_latency']=='Batch' and not data['gc_server'],'GC policy')
 req(data['registry_count']==262144 and data['architecture']=='X64','Runtime fixture')
 req(data['minimum_sample_ms']==1 and data['allocation_budget']==64*1024*1024,'Protocol limits')
 planned=list(counts)[:23] if data['history']=='prefix' else [TARGET]
 req([x['id'] for x in data['rows']]==planned,'Prefix/target order or duplicate')
 for row in data['rows']:
  req(row['iterations']==counts[row['id']],'Fixed iteration mismatch');common.check_row(row)
  req(all(row[k]==FROZEN_ROWS[row['id']][k] for k in common.MATCH_FIELDS),'Prefix/target fixture mismatch')
  req(all(x['total_bytes']<=64*1024*1024 for x in row['samples']),'Allocation ceiling')
 row=data['rows'][-1];req(row['id']==TARGET and row['iterations']==973,'Target count')
 req(all(x['bytes_per_op']==32848 for x in row['samples']),'Target allocation contract')
 return row
def analyze(root):
 from run import verify_generation
 verify_generation()
 m=json.loads((root/'manifest.json').read_text());req(m.get('completed_utc'),'Incomplete manifest')
 for f,h in m['source_hashes'].items():req(sha(Path(f))==h,'Diagnostic source/count plan changed')
 for f,h in m['external_source_hashes'].items():req(sha(Path(f))==h,'Frozen reference changed')
 req(set(m['identities'])==set(HASHES),'Identity coverage')
 for v,i in m['identities'].items():verify_identity(i,v)
 counts=json.loads((ROOT/'iterations.json').read_text());req(counts==json.loads((BENCH/'results/final-builder-nohw/iterations-Dense.json').read_text()),'Original count plan mismatch')
 req(list(counts)[22]==TARGET and counts[TARGET]==973,'Saved target')
 records={};runtime=None;mvid={};seen=set();sample_count=0
 expected={(r,c,h,a) for r in range(3) for c in ['work','sorted'] for h in ['first','prefix'] for a in ['A','B','AA']}
 for meta in m['runs']:
  key=(meta['round'],meta['caller'],meta['history'],meta['arm']);req(key in expected and key not in records,'Duplicate/unexpected arm');label=meta['label'];req(label not in seen,'Duplicate label');seen.add(label)
  req(meta['returncode']==0,'Failed process');v='selected' if key[3]=='B' else 'baseline';req(meta['variant']==v,'Variant arm')
  for ext,k in [('json','result_sha256'),('stdout','stdout_sha256'),('stderr','stderr_sha256')]:req(sha(root/(label+'.'+ext))==meta[k],'Raw file changed')
  d=json.loads((root/(label+'.json')).read_text());req(d==json.loads((root/(label+'.stdout')).read_text()),'Raw parsed data disagreement')
  row=check_process(d,meta,m['identities'][v],counts);records[key]=row;sample_count+=sum(len(x['samples']) for x in d['rows'])
  now={k:d[k] for k in common.RUNTIME_FIELDS if k!='group'}
  if runtime is None:runtime=now
  else:req(runtime==now,'Cross-process runtime mismatch')
  if v in mvid:req(mvid[v]==d['runtime_assembly_mvid'],'MVID mismatch')
  else:mvid[v]=d['runtime_assembly_mvid']
 req(set(records)==expected,'Missing arms or cells')
 frozen=json.loads((BENCH/'results/final-builder-nohw/r0-Dense-A.json').read_text())['rows'][22]
 req(all(all(row[k]==frozen[k] for k in common.MATCH_FIELDS) for row in records.values()),'Target fixture/contract differs from frozen cohort')
 out=[]
 for caller in ['work','sorted']:
  for history in ['first','prefix']:
   rr=[];cross=[];ratios=[];drifts=[];tails=[];p95=[];valid=True
   for r in range(3):
    rows={a:records[(r,caller,history,a)] for a in ['A','B','AA']};samples={a:[s['ns_per_op'] for s in row['samples']] for a,row in rows.items()};med={a:median(s) for a,s in samples.items()}
    comparisons={a:med['B']/med[a] for a in ['A','AA']};p={a:common.percentile(samples['B'],.95)/common.percentile(samples[a],.95) for a in ['A','AA']};t={a:max(samples['B'])/max(samples[a]) for a in ['A','AA']}
    ratio=med['B']/math.sqrt(med['A']*med['AA']);drift=med['AA']/med['A'];ratios.append(ratio);drifts.append(abs(drift-1));cross.extend(comparisons.values());p95.extend(p.values());tails.extend(t.values());valid &= all(common.check_row(row) for row in rows.values())
    rr.append({'round':r,'median_ns':med,'candidate_over_a':comparisons['A'],'candidate_over_aa':comparisons['AA'],'aa_ratio':drift,'ratio':ratio,'p95_over_a':p['A'],'p95_over_aa':p['AA'],'max_over_a':t['A'],'max_over_aa':t['AA'],'gcs':{a:[s['gcs'] for s in row['samples']] for a,row in rows.items()}})
   threshold=max(.03,max(drifts));verdict='invalid-sample' if not valid else 'clear-regression' if all(x>1+threshold for x in cross) else 'clear-improvement' if all(x<1-threshold for x in cross) else 'uncertain-or-small'
   out.append({'caller':caller,'history':history,'ratio':median(ratios),'crossing_min':min(cross),'crossing_max':max(cross),'aa_drift_max':max(drifts),'threshold':threshold,'verdict':verdict,'p95_tail_ratio_max':max(p95),'max_tail_ratio_max':max(tails),'minimum_ms':min(s['elapsed_ms'] for r in range(3) for a in ['A','B','AA'] for s in records[(r,caller,history,a)]['samples']),'rounds':rr})
 reproduced=next(x for x in out if x['caller']=='work' and x['history']=='prefix')['verdict']=='clear-regression'
 return {'processes':len(records),'samples':sample_count,'target_samples':len(records)*7,'work_prefix_reproduced':reproduced,'contrast_interpretation_allowed':reproduced,'historical_final_work_prefix_ratio':1.2647733701434534,'rows':out,'scope':'Context diagnostic only; no frozen verdict recategorized. Association is not proof of placement/GC mechanism. No further experiment without parent direction.'}
def main():
 result=analyze(ROOT/'results');(ROOT/'results/summary.json').write_text(json.dumps(result,indent=2));print(json.dumps({**{k:v for k,v in result.items() if k!='rows'},'rows':[{k:v for k,v in x.items() if k!='rounds'} for x in result['rows']]},indent=2))
if __name__=='__main__':main()
