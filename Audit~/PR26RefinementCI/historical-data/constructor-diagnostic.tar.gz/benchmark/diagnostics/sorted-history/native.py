#!/usr/bin/env python3
"""Untimed final-reference and diagnostic-host captures; original evidence untouched."""
from pathlib import Path
import argparse,json,subprocess,time,re,difflib
from run import ROOT,BENCH,SDK,sha,env,verify,EXPECTED,FACADE
PATTERNS='*FromSortedUnique* *ValidateAndFillSorted* *DirectArraySet:.ctor* *Work* *SortedOnly*'
def sections(p):
 out={}
 for part in p.read_text().split('; Assembly listing for method ')[1:]:
  header=part.splitlines()[0];lines=[]
  for line in part.splitlines()[1:]:
   if line.strip().startswith(';') or not line.strip():continue
   lines.append(re.sub(r'0x[0-9A-Fa-f]{12}(?![0-9A-Fa-f])','<ADDR>',line.split(';;')[0].rstrip()))
  out[header]=lines
 return out
def main():
 import os
 p=argparse.ArgumentParser();p.add_argument('kind',choices=['reference','diagnostic']);a=p.parse_args();parent=ROOT/'native'/a.kind;parent.mkdir(parents=True,exist_ok=False)
 paths={}
 for variant in ['baseline','selected']:
  identpath=(BENCH/'builds'/('runtime-baseline' if variant=='baseline' else 'final-selected')/'identity.json') if a.kind=='reference' else ROOT/'builds'/variant/'identity.json'
  ident=json.loads(identpath.read_text());verify(ident);assert ident['runtime_dll_sha256']==EXPECTED[variant] and ident['facade_dll_sha256']==FACADE;out=parent/variant;out.mkdir();e=env()
  for prefix in ['DOTNET_','COMPlus_']:e[prefix+'JitDisasm']=PATTERNS;e[prefix+'JitStdOutFile']=str(out/'methods.asm')
  args=['Dense','builder','calibrate'] if a.kind=='reference' else ['work','first',str(ROOT/'iterations.json')]
  cmd=['taskset','-c',str(min(os.sched_getaffinity(0))),str(SDK),ident['dll'],*args];start=time.time();r=subprocess.run(cmd,env=e,capture_output=True,text=True)
  (out/'stdout.txt').write_text(r.stdout);(out/'stderr.txt').write_text(r.stderr);record={'kind':'untimed-native-diagnostic','command':cmd,'returncode':r.returncode,'elapsed_s':time.time()-start,'identity':ident,'requested_patterns':PATTERNS}
  if r.returncode==0:
   d=json.loads(r.stdout);assert d['runtime_assembly_sha256']==ident['runtime_dll_sha256'];record['observed_runtime_sha256']=d['runtime_assembly_sha256']
  record['file_sha256']={p.name:sha(p) for p in out.iterdir() if p.is_file()};(out/'capture.json').write_text(json.dumps(record,indent=2));assert r.returncode==0,r.stderr;paths[variant]=out/'methods.asm'
 left,right=(sections(paths[v]) for v in ['baseline','selected']);records=[]
 for method in sorted(set(left)|set(right)):
  if not method.startswith(('Probe:','GameplayTags.Experiments.DirectArraySet:')):continue
  equal=method in left and method in right and left[method]==right[method];record={'method':method,'normalized_equal':equal,'baseline_lines':len(left.get(method,[])),'selected_lines':len(right.get(method,[]))};records.append(record)
  if not equal:
   name=re.sub(r'[^A-Za-z0-9]+','_',method)[:110]+'.diff';(parent/name).write_text('\n'.join(difflib.unified_diff(left.get(method,[]),right.get(method,[]),fromfile='baseline',tofile='selected'))+'\n');record['diff_file']=name
 expected=['GameplayTags.Experiments.DirectArraySet:FromSortedUnique(', 'GameplayTags.Experiments.DirectArraySet:ValidateAndFillSorted(', 'GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,int)', 'GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,bool)', 'Probe:Work(']
 if a.kind=='diagnostic':expected.append('Probe:SortedOnly(')
 coverage={label:{prefix:[m for m in methods if m.startswith(prefix)] for prefix in expected} for label,methods in [('baseline',left),('selected',right)]}
 missing={label:[prefix for prefix,headers in groups.items() if not headers] for label,groups in coverage.items()}
 result={'scope':a.kind,'expected_prefixes':expected,'coverage':coverage,'missing_headers':missing,'missing_note':'Absent headers may be inlined or not reached; no comparison claim is made for them.','normalization':'Comments/blank lines removed and only 12-digit process addresses normalized; raw addresses preserved in methods.asm. Not a machine-byte identity assertion.','methods':records};(parent/'comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
