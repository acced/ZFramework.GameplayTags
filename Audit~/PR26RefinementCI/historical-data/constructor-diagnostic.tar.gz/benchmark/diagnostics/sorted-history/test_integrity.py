#!/usr/bin/env python3
"""Focused rejection checks against copied frozen data; no benchmark execution."""
import copy,json
from analyze import BENCH,ROOT,check_process,verify_identity
base=json.loads((BENCH/'results/final-builder-nohw/r0-Dense-A.json').read_text())
base.update(caller='work',history='prefix',prefix_rows=22,target_id='builder/cluster/4096/build/sorted/same/0',target_iterations=973)
base['rows']=base['rows'][:23]
ident=json.loads((BENCH/'builds/runtime-baseline/identity.json').read_text());counts=json.loads((ROOT/'iterations.json').read_text());meta={'caller':'work','history':'prefix'}
check_process(base,meta,ident,counts);verify_identity(ident,'baseline')
checks=[]
def reject(name,mutate):
 data=copy.deepcopy(base);mutate(data)
 try:check_process(data,meta,ident,counts)
 except (ValueError,KeyError,TypeError):checks.append(name);return
 raise AssertionError('Accepted corruption: '+name)
reject('missing prefix row',lambda d:d['rows'].pop(0))
reject('duplicate prefix row',lambda d:d['rows'].__setitem__(0,d['rows'][1]))
reject('prefix iteration mismatch',lambda d:d['rows'][0].__setitem__('iterations',619))
reject('prefix input mismatch',lambda d:d['rows'][8].__setitem__('input_hash','bad'))
reject('target iteration mismatch',lambda d:d['rows'][-1].__setitem__('iterations',394))
reject('loaded path mismatch',lambda d:d.__setitem__('runtime_assembly_path','/tmp/GameplayTags.dll'))
reject('loaded hash mismatch',lambda d:d.__setitem__('runtime_assembly_sha256','bad'))
reject('hardware enabled',lambda d:d.__setitem__('avx2',True))
reject('GC policy',lambda d:d.__setitem__('gc_latency','Interactive'))
reject('duplicate sample',lambda d:d['rows'][-1]['samples'].__setitem__(1,d['rows'][-1]['samples'][0]))
reject('NaN elapsed',lambda d:d['rows'][-1]['samples'][0].__setitem__('elapsed_ms',float('nan')))
reject('allocation contract',lambda d:d['rows'][-1]['samples'][0].update(total_bytes=1,bytes_per_op=1/973))
reject('target caller mismatch',lambda d:d.__setitem__('caller','sorted'))
result={'positive_frozen_prefix_accepted':True,'corruptions_rejected':checks,'note':'Short original prefix samples are preserved and accepted as history; target validity is assessed separately in full analysis.'}
(ROOT/'integrity-checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
