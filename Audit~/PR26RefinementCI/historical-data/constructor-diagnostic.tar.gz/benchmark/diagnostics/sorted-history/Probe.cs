using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Text.Json;
using System.Security.Cryptography;
using System.Text;
using System.Runtime.CompilerServices;
using GameplayTags;
using Set = GameplayTags.Experiments.DirectArraySet;
using Layout = GameplayTags.Experiments.BitmapLayout;
class Probe {
 static string RuntimeAssemblyPath => typeof(Set).Assembly.Location;
 static string RuntimeAssemblyHash => Convert.ToHexString(SHA256.HashData(System.IO.File.ReadAllBytes(RuntimeAssemblyPath))).ToLowerInvariant();
 static string RuntimeAssemblyMvid => typeof(Set).Assembly.ManifestModule.ModuleVersionId.ToString();
 const int Universe=262144; const long AllocationBudget=64L*1024*1024; const double TargetMs=5, MinimumMs=1;
 static TagRegistry reg; static Layout layout; static Set left,right,output,empty,keep; static RuntimeTag[] input,peer,probes; static int[] ids,other,inputSnapshot,peerSnapshot; static long sink, expected; static bool unordered, dirty; static RuntimeTag dirtyTag; static string op, id; static readonly List<object> rows=new();
 record Case(string Group,string Shape,string Op,int Count,string Flavor,string Peer="same",int PeerCount=0) { public string Key=>$"{Group}/{Shape}/{Count}/{Op}/{Flavor}/{Peer}/{PeerCount}"; }
 static void Check(bool test,string msg){if(!test)throw new Exception(id+": "+msg);}
 static Set Build(RuntimeTag[] tags, bool unordered=false, Layout? kind=null) => unordered?Set.FromUnordered(reg,tags,0,kind??layout):Set.FromSortedUnique(reg,tags,0,kind??layout);
 static int[] Ids(string shape,int n,int offset=0) => Enumerable.Range(0,n).Select(i=>shape=="cluster"?8192+offset+i:1024+offset+i*32).ToArray();
 static IEnumerable<Case> Cases(string group) {
  if(group=="query")foreach(int n in new[]{0,1,2,8,32,64})foreach(string f in n==0?new[]{"miss-low","miss-high"}:new[]{"hit-first","hit-middle","hit-last","miss-bit","miss-low","miss-high","balanced"})yield return new("query","scatter","query64",n,f);
  if(group=="builder") {
   foreach(int n in new[]{0,1,2})foreach(string f in new[]{"sorted","shuffled"})yield return new("builder","scatter","build",n,f);
   foreach(int n in new[]{8,64,4096})foreach(string s in new[]{"cluster","scatter"})foreach(string f in new[]{"sorted","shuffled","reversed","duplicates"})yield return new("builder",s,"build",n,f);
  }
  if(group=="growth")foreach(int n in new[]{8,4096})foreach(string shape in new[]{"cluster","scatter"})foreach(string peer in new[]{"micro","dense"})foreach(string operation in new[]{"fresh-micro-union","tight-micro-union","upper-micro-union"})yield return new("growth",shape,operation,n,"equal",peer,n);
  if(group=="popcount")foreach(int n in new[]{8,4096})foreach(string s in new[]{"cluster","scatter"})foreach(string peer in new[]{"same","opposite"})foreach(string op in new[]{"union","restore-remove"})yield return new("popcount",s,op,n,"equal",peer,n);
  if(group=="mixed") {
   foreach(int n in new[]{8,4096})foreach(string s in new[]{"cluster","scatter"})foreach(string peer in new[]{"same","opposite"})foreach(string op in new[]{"union","restore-append","restore-remove","copy"})yield return new("mixed",s,op,n,"equal",peer,n);
   foreach(string s in new[]{"cluster","scatter"})foreach(string peer in new[]{"same","opposite"})foreach(string op in new[]{"union","restore-append","restore-remove"})foreach(bool reverse in new[]{false,true})yield return new("mixed",s,op,reverse?8:4096,reverse?"small-large":"large-small",peer,reverse?4096:8);
   foreach(string peer in new[]{"same","opposite"})foreach(string op in new[]{"union","restore-append","restore-remove","copy"})yield return new("mixed","random",op,4096,"equal",peer,4096);
   yield return new("mixed","random","charged-build-union64",4096,"shuffled","same",4096);
   foreach(string f in new[]{"clean","dirty"})foreach(int n in new[]{0,8,4096})yield return new("mixed","scatter","empty-copy",n,f);
   foreach(int n in new[]{8,4096})foreach(string s in new[]{"cluster","scatter"})yield return new("mixed",s,"charged-build-union64",n,"shuffled","same",n);
  }
 }
 static void Shuffle(RuntimeTag[] a){var r=new Random(773);for(int i=a.Length-1;i>0;i--){int j=r.Next(i+1);(a[i],a[j])=(a[j],a[i]);}}
 static void Validate(Set s,IEnumerable<int> values){var want=values.Distinct().OrderBy(x=>x).ToArray();var have=new List<int>();foreach(var t in s)have.Add(t.RuntimeIndex);Check(s.Count==want.Length&&have.SequenceEqual(want),"exact members/count");s.AssertInvariants();}
 static void Setup(Case c){id=c.Key;op=c.Op;unordered=c.Flavor!="sorted";dirty=c.Flavor=="dirty";dirtyTag=reg.GetTagAt(1);ids=Ids(c.Shape,c.Count);other=Ids(c.Shape,c.PeerCount,c.Shape=="cluster"?c.Count/2:16);if(c.Shape=="random"){var random=new Random(20261002);var bag=new HashSet<int>();while(bag.Count<c.Count+c.PeerCount/2)bag.Add(random.Next(Universe));var all=bag.ToArray();ids=all.Take(c.Count).OrderBy(x=>x).ToArray();other=all.Skip(c.Count/2).OrderBy(x=>x).ToArray();}input=ids.Select(reg.GetTagAt).ToArray();peer=other.Select(reg.GetTagAt).ToArray();if(c.Flavor=="duplicates")input=input.Concat(input).ToArray();if(c.Flavor is "shuffled" or "duplicates")Shuffle(input);if(c.Flavor=="reversed")Array.Reverse(input);if(op=="charged-build-union64")Shuffle(peer);inputSnapshot=input.Select(t=>t.RuntimeIndex).ToArray();peerSnapshot=peer.Select(t=>t.RuntimeIndex).ToArray();
  left=Build(ids.Select(reg.GetTagAt).ToArray(),false,c.Group=="growth"?Layout.Dense:layout);var peerKind=c.Group=="growth"?(c.Peer=="micro"?Layout.Micro:Layout.Dense):c.Peer=="opposite"?(left.Layout==Layout.Dense?Layout.Micro:Layout.Dense):layout;right=Build(other.Select(reg.GetTagAt).ToArray(),false,peerKind);output=new Set(reg,op=="tight-micro-union"?ids.Concat(other).Select(x=>x>>4).Distinct().Count():Math.Min(Universe,Math.Max(1,c.Count+c.PeerCount)),c.Group=="growth"?Layout.Micro:layout);empty=new Set(reg,0,peerKind);probes=new RuntimeTag[64];
  if(op=="query64"){int q=c.Flavor switch {"hit-first"=>ids[0],"hit-middle"=>ids[ids.Length/2],"hit-last"=>ids[^1],"miss-bit"=>ids[ids.Length/2]+1,"miss-low"=>0,_=>Universe-1};Array.Fill(probes,reg.GetTagAt(q));expected=ids.Contains(q)?64:0;if(c.Flavor=="balanced"){for(int i=0;i<64;i++)probes[i]=reg.GetTagAt(i%2==0?ids[(i*7)%ids.Length]:Universe-1);expected=32;}}
  else if(op=="build")expected=c.Count;
  else if(op=="copy")expected=c.PeerCount;
  else if(op=="restore-remove")expected=ids.Except(other).LongCount();
  else if(op=="empty-copy")expected=0;
  else expected=ids.Union(other).LongCount()*(op=="charged-build-union64"?64:1);
  Validate(left,ids);Validate(right,other);if(op=="build") {var built=Build(input,c.Flavor!="sorted");Validate(built,ids);Check(built.ReservedMemberCapacity>=Math.Min(input.Length,Universe),"factory reserved contract");}
  if(op=="empty-copy"&&dirty){Check(output.AddTag(dirtyTag),"dirty Add returned false");Check(output.HasTagExact(dirtyTag)&&output.Count==1,"dirty member absent");output.CopyFrom(empty);Validate(output,Array.Empty<int>());}var capacity=output.ReservedMemberCapacity;var kind=output.Layout;Check(Work(1)==expected,"work oracle");Check(output.ReservedMemberCapacity>=capacity&&output.Layout==kind,"reservation/layout stable");ValidateCurrent(c);
  if(op!="build"&&op!="charged-build-union64"&&op!="fresh-micro-union") {Work(8);long b=GC.GetAllocatedBytesForCurrentThread();Work(32);Check(GC.GetAllocatedBytesForCurrentThread()==b,"warmed operation allocated");}
 }
 static void ValidateCurrent(Case c){Validate(left,ids);Validate(right,other);Check(input.Select(t=>t.RuntimeIndex).SequenceEqual(inputSnapshot)&&peer.Select(t=>t.RuntimeIndex).SequenceEqual(peerSnapshot),"caller input mutated");if(op=="query64")Validate(left,ids);else if(op is "build" or "charged-build-union64" or "fresh-micro-union")Validate(keep,op=="build"?ids:ids.Union(other));else if(op=="empty-copy")Validate(output,Array.Empty<int>());else if(op=="copy")Validate(output,other);else if(op=="restore-remove")Validate(output,ids.Except(other));else Validate(output,ids.Union(other));}
 [MethodImpl(MethodImplOptions.NoInlining)] static long Work(int n){long sum=0;switch(op){
  case "query64":for(int j=0;j<n;j++)for(int i=0;i<64;i++)sum+=left.HasTagExact(probes[i])?1:0;break;
  case "build":if(unordered){for(int j=0;j<n;j++){var s=Set.FromUnordered(reg,input,0,layout);sum+=s.Count;keep=s;}}else{for(int j=0;j<n;j++){var s=Set.FromSortedUnique(reg,input,0,layout);sum+=s.Count;keep=s;}}break;
  case "tight-micro-union":case "upper-micro-union":case "union":for(int j=0;j<n;j++){Set.UnionInto(left,right,output);sum+=output.Count;}break;
  case "copy":for(int j=0;j<n;j++){output.CopyFrom(right);sum+=output.Count;}break;
  case "restore-append":for(int j=0;j<n;j++){output.CopyFrom(left);output.AppendTags(right);sum+=output.Count;}break;
  case "restore-remove":for(int j=0;j<n;j++){output.CopyFrom(left);output.RemoveTags(right);sum+=output.Count;}break;
  case "empty-copy":if(dirty){for(int j=0;j<n;j++){output.AddTag(dirtyTag);output.CopyFrom(empty);sum+=output.Count;}}else{output.Clear();for(int j=0;j<n;j++){output.CopyFrom(empty);sum+=output.Count;}}break;
  case "fresh-micro-union":for(int j=0;j<n;j++){var o=new Set(reg,0,Layout.Micro);Set.UnionInto(left,right,o);sum+=o.Count;keep=o;}break;
  case "charged-build-union64":for(int j=0;j<n;j++){var a=Set.FromUnordered(reg,input,0,layout);var b=Set.FromUnordered(reg,peer,0,layout);var o=new Set(reg,input.Length+peer.Length,layout);for(int k=0;k<64;k++){Set.UnionInto(a,b,o);sum+=o.Count;}keep=o;}break;
 }sink^=sum;return sum;}
 static (double ms,long bytes,int[] gcs) Timed(int n){int a0=GC.CollectionCount(0),a1=GC.CollectionCount(1),a2=GC.CollectionCount(2);long a=GC.GetAllocatedBytesForCurrentThread(),t=Stopwatch.GetTimestamp();long answer=Work(n);long stop=Stopwatch.GetTimestamp(),b=GC.GetAllocatedBytesForCurrentThread();Check(answer==expected*n,"timed checksum");return ((stop-t)*1000.0/Stopwatch.Frequency,b-a,new[]{GC.CollectionCount(0)-a0,GC.CollectionCount(1)-a1,GC.CollectionCount(2)-a2});}
 static object Measure(Case c,int fixedN,bool calibration){Setup(c);Work(16);var trial=Timed(16);double alloc=trial.bytes/16.0;int limit=alloc==0?1<<25:Math.Max(1,(int)(AllocationBudget/alloc));int n=fixedN>0?fixedN:16;var calibrationSamples=new List<object>();
  if(calibration){while(true){var t=Timed(n);calibrationSamples.Add(new{n,elapsed_ms=t.ms,total_bytes=t.bytes});ValidateCurrent(c);if(t.ms>=TargetMs||n>=limit)break;long next=Math.Max(n+1,(long)Math.Ceiling(n*Math.Min(16,TargetMs/Math.Max(t.ms,0.001)*1.2)));n=(int)Math.Min(limit,next);}return new{id=c.Key,iterations=n,allocation_bytes_per_op=alloc,allocation_budget=AllocationBudget,samples=calibrationSamples};}
  Check(fixedN>0,"missing calibrated iteration count");Work(Math.Min(n,1024));var samples=new List<object>();bool valid=true;for(int s=0;s<7;s++){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();var t=Timed(n);valid &= t.ms>=MinimumMs;samples.Add(new{sample=s,elapsed_ms=t.ms,ns_per_op=t.ms*1e6/n,bytes_per_op=t.bytes/(double)n,total_bytes=t.bytes,gcs=t.gcs,valid=t.ms>=MinimumMs});ValidateCurrent(c);}
  return new{id=c.Key,group=c.Group,shape=c.Shape,count=c.Count,peer_count=c.PeerCount,flavor=c.Flavor,op=c.Op,peer=c.Peer,iterations=n,unit=op=="query64"?"ns/64 probes":"ns/full operation",valid,samples,input_hash=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join(",",input.Select(t=>t.RuntimeIndex))))),input_length=input.Length,peer_input_length=peer.Length,peer_hash=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join(",",peer.Select(t=>t.RuntimeIndex))))),output_count=op is "build" or "charged-build-union64" or "fresh-micro-union"?keep.Count:output.Count,left_layout=left.Layout.ToString(),right_layout=right.Layout.ToString(),output_layout=output.Layout.ToString(),input_payload_bytes=left.BufferBytes,peer_payload_bytes=right.BufferBytes,output_payload_bytes=op is "build" or "charged-build-union64" or "fresh-micro-union"?keep.BufferBytes:output.BufferBytes,reserved_capacity=op is "build" or "charged-build-union64" or "fresh-micro-union"?keep.ReservedMemberCapacity:output.ReservedMemberCapacity,expected_checksum_per_iteration=expected};
 }

 static bool sortedCaller;
 [MethodImpl(MethodImplOptions.NoInlining)] static long SortedOnly(int n){long sum=0;for(int j=0;j<n;j++){var s=Set.FromSortedUnique(reg,input,0,layout);sum+=s.Count;keep=s;}sink^=sum;return sum;}
 static long TargetWarm(int n)=>sortedCaller?SortedOnly(n):Work(n);
 static (double ms,long bytes,int[] gcs) TimedTarget(int n){int a0=GC.CollectionCount(0),a1=GC.CollectionCount(1),a2=GC.CollectionCount(2);long a=GC.GetAllocatedBytesForCurrentThread(),t=Stopwatch.GetTimestamp();long answer=sortedCaller?SortedOnly(n):Work(n);long stop=Stopwatch.GetTimestamp(),b=GC.GetAllocatedBytesForCurrentThread();Check(answer==expected*n,"timed checksum");return ((stop-t)*1000.0/Stopwatch.Frequency,b-a,new[]{GC.CollectionCount(0)-a0,GC.CollectionCount(1)-a1,GC.CollectionCount(2)-a2});}
 static object MeasureTarget(Case c,int fixedN,bool calibration){Setup(c);TargetWarm(16);var trial=TimedTarget(16);double alloc=trial.bytes/16.0;int limit=alloc==0?1<<25:Math.Max(1,(int)(AllocationBudget/alloc));int n=fixedN>0?fixedN:16;var calibrationSamples=new List<object>();
  if(calibration){while(true){var t=TimedTarget(n);calibrationSamples.Add(new{n,elapsed_ms=t.ms,total_bytes=t.bytes});ValidateCurrent(c);if(t.ms>=TargetMs||n>=limit)break;long next=Math.Max(n+1,(long)Math.Ceiling(n*Math.Min(16,TargetMs/Math.Max(t.ms,0.001)*1.2)));n=(int)Math.Min(limit,next);}return new{id=c.Key,iterations=n,allocation_bytes_per_op=alloc,allocation_budget=AllocationBudget,samples=calibrationSamples};}
  Check(fixedN>0,"missing calibrated iteration count");TargetWarm(Math.Min(n,1024));var samples=new List<object>();bool valid=true;for(int s=0;s<7;s++){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();var t=TimedTarget(n);valid &= t.ms>=MinimumMs;samples.Add(new{sample=s,elapsed_ms=t.ms,ns_per_op=t.ms*1e6/n,bytes_per_op=t.bytes/(double)n,total_bytes=t.bytes,gcs=t.gcs,valid=t.ms>=MinimumMs});ValidateCurrent(c);}
  return new{id=c.Key,group=c.Group,shape=c.Shape,count=c.Count,peer_count=c.PeerCount,flavor=c.Flavor,op=c.Op,peer=c.Peer,iterations=n,unit=op=="query64"?"ns/64 probes":"ns/full operation",valid,samples,input_hash=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join(",",input.Select(t=>t.RuntimeIndex))))),input_length=input.Length,peer_input_length=peer.Length,peer_hash=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join(",",peer.Select(t=>t.RuntimeIndex))))),output_count=op is "build" or "charged-build-union64" or "fresh-micro-union"?keep.Count:output.Count,left_layout=left.Layout.ToString(),right_layout=right.Layout.ToString(),output_layout=output.Layout.ToString(),input_payload_bytes=left.BufferBytes,peer_payload_bytes=right.BufferBytes,output_payload_bytes=op is "build" or "charged-build-union64" or "fresh-micro-union"?keep.BufferBytes:output.BufferBytes,reserved_capacity=op is "build" or "charged-build-union64" or "fresh-micro-union"?keep.ReservedMemberCapacity:output.ReservedMemberCapacity,expected_checksum_per_iteration=expected};
 }

 static void Main(string[] args){
  layout=Layout.Dense; string caller=args[0],history=args[1];
  Check(caller is "work" or "sorted","caller");Check(history is "first" or "prefix","history");
  sortedCaller=caller=="sorted";
  var sizes=JsonSerializer.Deserialize<Dictionary<string,int>>(System.IO.File.ReadAllText(args[2]));
  var defs=Enumerable.Range(0,Universe).Select(i=>new GameplayTagDefinition("T"+i.ToString("D7"),"","Default",false,true)).ToList();
  var settings=UnityEngine.ScriptableObject.CreateInstance<GameplayTagSettings>();settings.ReplaceAll(defs,new List<GameplayTagRedirect>(),new List<GameplayTagSource>{new GameplayTagSource("Default","",false)});reg=TagRegistry.Create(settings);Check(reg.Count==Universe,"universe");
  // Same JIT warmup in every cell. Zero iterations produce no set allocations.
  Check(Work(0)==0&&SortedOnly(0)==0,"zero caller warmup");
  const string targetId="builder/cluster/4096/build/sorted/same/0";Check(sizes[targetId]==973,"fixed target count");
  if(history=="prefix"){
   int position=0;
   foreach(var c in Cases("builder")){
    if(position==22){Check(c.Key==targetId,"target position");rows.Add(MeasureTarget(c,973,false));break;}
    rows.Add(Measure(c,sizes[c.Key],false));position++;
   }
   Check(rows.Count==23,"prefix row count");
  }else rows.Add(MeasureTarget(new Case("builder","cluster","build",4096,"sorted"),973,false));
  Console.WriteLine(JsonSerializer.Serialize(new{schema=1,kind="bounded-constructor-diagnostic",caller,history,target_id=targetId,prefix_rows=history=="prefix"?22:0,target_iterations=973,telemetry="Original elapsed/allocation/GC collection counts only; CPU/pause/heap telemetry deferred",runtime_assembly_path=RuntimeAssemblyPath,runtime_assembly_sha256=RuntimeAssemblyHash,runtime_assembly_mvid=RuntimeAssemblyMvid,cross_assembly_calls=true,layout=layout.ToString(),minimum_sample_ms=MinimumMs,allocation_budget=AllocationBudget,runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,architecture=System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture.ToString(),vector_accelerated=System.Numerics.Vector.IsHardwareAccelerated,vector_uint_lanes=System.Numerics.Vector<uint>.Count,avx2=System.Runtime.Intrinsics.X86.Avx2.IsSupported,tiered_compilation=Environment.GetEnvironmentVariable("DOTNET_TieredCompilation"),hw_intrinsic=Environment.GetEnvironmentVariable("DOTNET_EnableHWIntrinsic"),gc_latency=System.Runtime.GCSettings.LatencyMode.ToString(),gc_server=System.Runtime.GCSettings.IsServerGC,ready_to_run=Environment.GetEnvironmentVariable("DOTNET_ReadyToRun"),tiered_pgo=Environment.GetEnvironmentVariable("DOTNET_TieredPGO"),gc_concurrent=Environment.GetEnvironmentVariable("DOTNET_gcConcurrent"),registry_count=reg.Count,rows,sink}));
 }
}
