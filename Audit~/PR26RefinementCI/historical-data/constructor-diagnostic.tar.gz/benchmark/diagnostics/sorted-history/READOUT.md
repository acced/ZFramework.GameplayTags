# Fixed-count constructor diagnostic

The required original Work + prefix reproduction gate did not pass. Its descriptive candidate/baseline ratio is 1.172, compared with 1.265 in the frozen final cohort, but the six crossings span 1.069–1.256 while the largest A/A drift is 10.6%. This follow-up therefore does not establish the cause of the original regression, and the original result remains unchanged.

All 36 processes completed successfully. There are 252 target samples and 2,772 replayed prefix samples. Every target sample exceeds 1 ms, uses exactly 973 operations and allocates 32,848 B/op. Output, caller inputs, source sets, reservation and payload contracts match the frozen cell. The prefix replays its exact 22 rows, counts and original measurement/GC policy, retains the original rows and static roots, and keeps lazy case enumeration through the target. Short prefix samples remain visible as history.

| Target caller | History | Median bracket ratio | Six crossings | Max A/A drift | Verdict | Max p95 / max batch tail |
|---|---|---:|---|---:|---|---|
| Original Work | Target first | 1.013 | 0.950–1.056 | 6.8% | Uncertain/small | 1.040 / 1.028 |
| Original Work | 22-row prefix | 1.172 | 1.069–1.256 | 10.6% | Uncertain/small | 1.536 / 1.573 |
| SortedOnly | Target first | 0.992 | 0.943–1.020 | 5.6% | Uncertain/small | 1.032 / 1.035 |
| SortedOnly | 22-row prefix | 1.230 | 1.165–1.257 | 3.5% | Clear median regression | 1.318 / 1.327 |

The dedicated caller's prefix loss is retained. It does not make the prerequisite pass for the original caller, and it is not proof of a caller or GC mechanism. The study stops at this bounded observation; no source optimization, extra telemetry experiment or full-cohort rerun follows from these results.

Collection patterns are informative but not a timing attribution: every target-first process has three samples with zero collections followed by four with 15 Gen0 collections. Every prefix-history target sample has 15 Gen0 collections. Gen1/Gen2 counts are zero in all target samples. These patterns are identical across baseline, candidate and A/A arms at each coordinate. Thus fixed iterations alone do not fix the collection regime; collection counts alone also do not record pause duration, heap/object placement or CPU scheduling.

## Exact native evidence

This follow-up directly captures final candidate Runtime DLL 1c032a39cf571ba4ef80ff22c12dd99049b01e1ce0a2cd34040868d899188fa3 against baseline 1dd0309a59eb38834eed5da8edfd4e959d9b584457976ed5c69d61fcc2a4d834. It does not inherit equality from the historical f98 v2 capture.

Both original reference-host and isolated diagnostic-host captures contain every requested header: FromSortedUnique, ValidateAndFillSorted, both constructors and Work; the diagnostic also contains SortedOnly. Within each host, all corresponding baseline/candidate instruction text matches after removing comments/blank lines and replacing only 12-digit process addresses. Raw addresses and complete emitted text are retained. This is not relocated machine-byte identity or proof of identical placement.

Across original and diagnostic hosts, Work, factory and fill instruction text match. Both constructors differ only at the immediate supplied before CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS (33 versus 54), identically for both libraries. That difference remains explicit in the cross-host diff. Shared zero-iteration caller preparation and the new host still change context, which is why the reproduction prerequisite was fixed in advance.

## Reproduction and retained evidence

- PROTOCOL.md fixes scope, roles, count/GC policy and interpretation prerequisite
- prepare.py / generation-proof.json preserve the entire original source prefix through Main and pin the copied count plan
- build.py binds the admitted Runtime/facade/compiler manifests; run.py records the serial schedule and every raw result
- analyze.py checks exact role identities, raw hashes, all four cells/three rounds/three arms, exact prefix and target contracts, actual sample/allocation validity and all six crossings/tails
- integrity-checks.json retains 13 corruption-rejection checks
- native/reference, native/diagnostic and native/cross-host-comparison.json retain native provenance and every present/missing requested header
- results/manifest.json, raw stdout/JSON and summary.json retain all observations

No GC pause/heap/CPU telemetry objects were added to this first factorial, since doing so would change retained roots before later full collections. No NoGCRegion, new production method attribute, library mutation or acceptance-threshold change was introduced. These remain single-host .NET8 x64 disabled-intrinsic diagnostics, separate from the frozen milestone and without Unity/Mono/IL2CPP/Burst or other-host claims.
