#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,subprocess,time,platform
ROOT=Path(__file__).resolve().parent
BENCH=ROOT.parents[1]
SDK=BENCH.parent.parent/'comparison-materials/dotnet-sdk/dotnet'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def env():
 d=dict(os.environ,DOTNET_GENERATE_ASPNET_CERTIFICATE='false',DOTNET_CLI_TELEMETRY_OPTOUT='1',DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1',DOTNET_CLI_HOME=str(ROOT/'home'))
 for p in ['DOTNET_','COMPlus_']:
  for k in ['TieredCompilation','TieredPGO','ReadyToRun','gcConcurrent','EnableHWIntrinsic']:d[p+k]='0'
 return d
EXPECTED={'baseline':'1dd0309a59eb38834eed5da8edfd4e959d9b584457976ed5c69d61fcc2a4d834','selected':'1c032a39cf571ba4ef80ff22c12dd99049b01e1ce0a2cd34040868d899188fa3'}
FACADE='de451e90cbba4d9a2ffba95b7a1b0dd319b2ca6f8ec94941f16e78d430f95a51'
def identity(name):
 d=json.loads((ROOT/'builds'/name/'identity.json').read_text());verify(d)
 assert d['runtime_dll_sha256']==EXPECTED[name] and d['facade_dll_sha256']==FACADE
 return d
def verify_generation():
 proof=json.loads((ROOT/'generation-proof.json').read_text())
 assert sha(proof['origin'])==proof['origin_sha256'] and sha(ROOT/'Probe.cs')==proof['harness_sha256']
 assert proof['original_before_Main_preserved'] and proof['target_iterations']==973 and proof['prefix_rows']==22
 original=Path(proof['origin']).read_text();assert (ROOT/'Probe.cs').read_text().startswith(original[:original.index(' static void Main(')])
 assert sha(proof['iterations_origin'])==proof['iterations_sha256']==sha(ROOT/'iterations.json')

def verify(d):
 assert sha(d['dll'])==d['dll_sha256'] and sha(d['runtime_dll'])==d['runtime_dll_sha256']
 for f,h in {**d['source_sha256'],**d['dependency_sha256']}.items():assert sha(f)==h
 for k in ['admitted_build_binding','admitted_source_manifest']:assert sha(d[k]['path'])==d[k]['sha256']
def main():
 verify_generation()
 out=ROOT/'results';out.mkdir(exist_ok=False);cpu=min(os.sched_getaffinity(0));ids={v:identity(v) for v in ['baseline','selected']};e=env()
 m={'kind':'bounded-constructor-diagnostic','cpu_affinity':cpu,'hostname':platform.node(),'platform':platform.platform(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'identities':ids,'env':{k:v for k,v in e.items() if k.startswith(('DOTNET_','COMPlus_'))},'source_hashes':{str(p):sha(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in ['.cs','.py','.md','.json']},'external_source_hashes':{str(p):sha(p) for p in [BENCH/'analyze.py',BENCH/'Probe.Reference.cs',BENCH/'results/final-builder-nohw/iterations-Dense.json',BENCH/'results/final-builder-nohw/r0-Dense-A.json']},'runs':[]}
 cells=[('work','prefix'),('work','first'),('sorted','prefix'),('sorted','first')]
 for r in range(3):
  order=cells[r:]+cells[:r]
  for caller,history in order:
   arms=['A','B','AA'] if r%2==0 else ['AA','B','A']
   for arm in arms:
    variant='selected' if arm=='B' else 'baseline';ident=ids[variant];verify(ident)
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==m['boot_id']
    label=f'r{r}-{caller}-{history}-{arm}';cmd=['taskset','-c',str(cpu),str(SDK),ident['dll'],caller,history,str(ROOT/'iterations.json')]
    start=time.time();p=subprocess.run(cmd,env=e,capture_output=True,text=True)
    (out/(label+'.stdout')).write_text(p.stdout);(out/(label+'.stderr')).write_text(p.stderr)
    record={'label':label,'round':r,'caller':caller,'history':history,'arm':arm,'variant':variant,'command':cmd,'returncode':p.returncode,'elapsed_s':time.time()-start,'stdout_sha256':sha(out/(label+'.stdout')),'stderr_sha256':sha(out/(label+'.stderr'))};m['runs'].append(record)
    (out/'manifest.json').write_text(json.dumps(m,indent=2))
    if p.returncode:raise RuntimeError(label+': '+p.stderr[-2000:])
    data=json.loads(p.stdout);assert data['runtime_assembly_sha256']==ident['runtime_dll_sha256'];assert Path(data['runtime_assembly_path'])==Path(ident['dll']).parent/'GameplayTags.dll'
    (out/(label+'.json')).write_text(json.dumps(data,indent=2));record['result_sha256']=sha(out/(label+'.json'))
    (out/'manifest.json').write_text(json.dumps(m,indent=2));print(label,round(record['elapsed_s'],2),'s',flush=True)
 m['completed_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(out/'manifest.json').write_text(json.dumps(m,indent=2))
if __name__=='__main__':main()
