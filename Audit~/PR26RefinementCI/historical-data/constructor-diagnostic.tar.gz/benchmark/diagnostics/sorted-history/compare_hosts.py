#!/usr/bin/env python3
from pathlib import Path
import json,difflib,re
from native import sections,ROOT
records=[]
for role in ['baseline','selected']:
 a=sections(ROOT/'native/reference'/role/'methods.asm');b=sections(ROOT/'native/diagnostic'/role/'methods.asm')
 for method in a:
  if not method.startswith(('Probe:Work','GameplayTags.Experiments.DirectArraySet:')):continue
  equal=method in b and a[method]==b[method];record={'role':role,'method':method,'original_vs_diagnostic_normalized_equal':equal};records.append(record)
  if not equal:
   name=role+'-'+re.sub(r'[^A-Za-z0-9]+','_',method)[:110]+'.diff';(ROOT/'native'/name).write_text('\n'.join(difflib.unified_diff(a[method],b.get(method,[]),fromfile='original-reference',tofile='diagnostic'))+'\n');record['diff_file']=name
(ROOT/'native/cross-host-comparison.json').write_text(json.dumps({'methods':records,'observation':'Both constructors differ only in mov esi,33 versus mov esi,54 before CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS. This immediate is retained by normalization; no machine-byte equality claim. Work, sorted factory and fill instruction text are equal across hosts. Within each host all compared baseline/selected bodies are equal.'},indent=2))
