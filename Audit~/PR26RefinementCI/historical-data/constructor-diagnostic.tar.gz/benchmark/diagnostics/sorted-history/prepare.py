#!/usr/bin/env python3
"""Generate a separate fixed-count caller × history diagnostic from frozen Reference.
The original Work, Setup, ValidateCurrent, Timed and Measure bodies are preserved.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BENCH=ROOT.parents[1]
src=BENCH/'Probe.Reference.cs'
s=src.read_text()
old_main=s[s.index(' static void Main('):]
# Keep the exact original measurement path for the 22 prefix rows.
insert=s.index(' static void Main(')
extra=r'''
 static bool sortedCaller;
 [MethodImpl(MethodImplOptions.NoInlining)] static long SortedOnly(int n){long sum=0;for(int j=0;j<n;j++){var s=Set.FromSortedUnique(reg,input,0,layout);sum+=s.Count;keep=s;}sink^=sum;return sum;}
 static long TargetWarm(int n)=>sortedCaller?SortedOnly(n):Work(n);
 static (double ms,long bytes,int[] gcs) TimedTarget(int n){int a0=GC.CollectionCount(0),a1=GC.CollectionCount(1),a2=GC.CollectionCount(2);long a=GC.GetAllocatedBytesForCurrentThread(),t=Stopwatch.GetTimestamp();long answer=sortedCaller?SortedOnly(n):Work(n);long stop=Stopwatch.GetTimestamp(),b=GC.GetAllocatedBytesForCurrentThread();Check(answer==expected*n,"timed checksum");return ((stop-t)*1000.0/Stopwatch.Frequency,b-a,new[]{GC.CollectionCount(0)-a0,GC.CollectionCount(1)-a1,GC.CollectionCount(2)-a2});}
'''
# Duplicate Measure only for the diagnostic target. Prefix Measure remains exact.
measure=s[s.index(' static object Measure('):insert]
measure=measure.replace(' static object Measure(', ' static object MeasureTarget(').replace('Work(', 'TargetWarm(').replace('Timed(', 'TimedTarget(')
main=r'''
 static void Main(string[] args){
  layout=Layout.Dense; string caller=args[0],history=args[1];
  Check(caller is "work" or "sorted","caller");Check(history is "first" or "prefix","history");
  sortedCaller=caller=="sorted";
  var sizes=JsonSerializer.Deserialize<Dictionary<string,int>>(System.IO.File.ReadAllText(args[2]));
  var defs=Enumerable.Range(0,Universe).Select(i=>new GameplayTagDefinition("T"+i.ToString("D7"),"","Default",false,true)).ToList();
  var settings=UnityEngine.ScriptableObject.CreateInstance<GameplayTagSettings>();settings.ReplaceAll(defs,new List<GameplayTagRedirect>(),new List<GameplayTagSource>{new GameplayTagSource("Default","",false)});reg=TagRegistry.Create(settings);Check(reg.Count==Universe,"universe");
  // Same JIT warmup in every cell. Zero iterations produce no set allocations.
  Check(Work(0)==0&&SortedOnly(0)==0,"zero caller warmup");
  const string targetId="builder/cluster/4096/build/sorted/same/0";Check(sizes[targetId]==973,"fixed target count");
  if(history=="prefix"){
   int position=0;
   foreach(var c in Cases("builder")){
    if(position==22){Check(c.Key==targetId,"target position");rows.Add(MeasureTarget(c,973,false));break;}
    rows.Add(Measure(c,sizes[c.Key],false));position++;
   }
   Check(rows.Count==23,"prefix row count");
  }else rows.Add(MeasureTarget(new Case("builder","cluster","build",4096,"sorted"),973,false));
  Console.WriteLine(JsonSerializer.Serialize(new{schema=1,kind="bounded-constructor-diagnostic",caller,history,target_id=targetId,prefix_rows=history=="prefix"?22:0,target_iterations=973,telemetry="Original elapsed/allocation/GC collection counts only; CPU/pause/heap telemetry deferred",runtime_assembly_path=RuntimeAssemblyPath,runtime_assembly_sha256=RuntimeAssemblyHash,runtime_assembly_mvid=RuntimeAssemblyMvid,cross_assembly_calls=true,layout=layout.ToString(),minimum_sample_ms=MinimumMs,allocation_budget=AllocationBudget,runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,architecture=System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture.ToString(),vector_accelerated=System.Numerics.Vector.IsHardwareAccelerated,vector_uint_lanes=System.Numerics.Vector<uint>.Count,avx2=System.Runtime.Intrinsics.X86.Avx2.IsSupported,tiered_compilation=Environment.GetEnvironmentVariable("DOTNET_TieredCompilation"),hw_intrinsic=Environment.GetEnvironmentVariable("DOTNET_EnableHWIntrinsic"),gc_latency=System.Runtime.GCSettings.LatencyMode.ToString(),gc_server=System.Runtime.GCSettings.IsServerGC,ready_to_run=Environment.GetEnvironmentVariable("DOTNET_ReadyToRun"),tiered_pgo=Environment.GetEnvironmentVariable("DOTNET_TieredPGO"),gc_concurrent=Environment.GetEnvironmentVariable("DOTNET_gcConcurrent"),registry_count=reg.Count,rows,sink}));
 }
}
'''
(ROOT/'Probe.cs').write_text(s[:insert]+extra+measure+main)
# Copy fixed counts rather than calibrate or silently alter target/prefix work.
counts=BENCH/'results/final-builder-nohw/iterations-Dense.json'
(ROOT/'iterations.json').write_bytes(counts.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof={'origin':str(src),'origin_sha256':sha(src),'harness_sha256':sha(ROOT/'Probe.cs'),'iterations_origin':str(counts),'iterations_sha256':sha(counts),'target_iterations':973,'prefix_rows':22,'original_before_Main_preserved':(ROOT/'Probe.cs').read_text().startswith(s[:insert])}
(ROOT/'generation-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
