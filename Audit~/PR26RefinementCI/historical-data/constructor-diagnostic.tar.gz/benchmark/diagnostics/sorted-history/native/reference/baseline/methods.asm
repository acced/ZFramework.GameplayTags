; Assembly listing for method GameplayTags.Experiments.DirectArraySet:FromSortedUnique(GameplayTags.TagRegistry,System.ReadOnlySpan`1[GameplayTags.RuntimeTag],int,int):GameplayTags.Experiments.DirectArraySet (FullOpts)
; Emitting BLENDED_CODE for generic X64 - Unix
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 3 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       push     rax
       lea      rbp, [rsp+0x30]
       mov      rbx, rdi
       mov      r12, rsi
       mov      r14d, edx
       mov      r13d, ecx
       mov      r15d, r8d
 
G_M000_IG02:                ;; offset=0x001F
       test     r14d, r14d
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0024
       mov      rdi, 0x7F2D1C05F5C8
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdi, r14
       mov      rsi, rbx
       mov      edx, r13d
       mov      ecx, r15d
       call     [GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,int):this]
       mov      rax, r14
 
G_M000_IG04:                ;; offset=0x004B
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x005A
       mov      rdi, rbx
       mov      esi, r13d
       mov      edx, r15d
       mov      ecx, r14d
       call     [GameplayTags.Experiments.DirectArraySet:ValidateBuildOptions(GameplayTags.TagRegistry,int,int,int):int]
       mov      r13d, eax
       cmp      r14d, 1
       jne      G_M000_IG11
       mov      rdi, gword ptr [r12]
       mov      r14d, dword ptr [r12+0x08]
       cmp      rdi, rbx
       jne      G_M000_IG13
       mov      rdi, 0x7F2D1C05F5C8
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdi, rbx
       mov      esi, r13d
       mov      edx, r15d
       call     [GameplayTags.Experiments.DirectArraySet:WantsDense(GameplayTags.TagRegistry,int,int):bool]
       mov      ecx, eax
       mov      rsi, rbx
       mov      edx, r13d
       mov      rdi, r12
       call     [GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,bool):this]
       mov      ecx, r14d
       mov      rax, gword ptr [r12+0x10]
       test     rax, rax
       je       SHORT G_M000_IG06
       mov      edi, ecx
       sar      edi, 6
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG14
       mov      edx, 1
       shl      rdx, cl
       mov      qword ptr [rax+8*rdi+0x10], rdx
       jmp      SHORT G_M000_IG09
 
G_M000_IG06:                ;; offset=0x00E7
       mov      eax, ecx
       shr      eax, 4
       shl      eax, 16
       and      ecx, 15
       mov      edi, 1
       shl      edi, cl
       or       eax, edi
       mov      rdi, gword ptr [r12+0x08]
       test     rdi, rdi
       jne      SHORT G_M000_IG07
       mov      dword ptr [r12+0x20], eax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rdi+0x08], 0
       jbe      G_M000_IG14
       mov      dword ptr [rdi+0x10], eax
 
G_M000_IG08:                ;; offset=0x0119
       mov      dword ptr [r12+0x24], 1
 
G_M000_IG09:                ;; offset=0x0122
       mov      dword ptr [r12+0x28], 1
       mov      rax, r12
 
G_M000_IG10:                ;; offset=0x012E
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x013D
       mov      rdi, 0x7F2D1C05F5C8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, rbx
       mov      esi, r13d
       mov      edx, r15d
       call     [GameplayTags.Experiments.DirectArraySet:WantsDense(GameplayTags.TagRegistry,int,int):bool]
       mov      ecx, eax
       mov      rsi, rbx
       mov      edx, r13d
       mov      rdi, gword ptr [rbp-0x30]
       call     [GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,bool):this]
       mov      rsi, r12
       mov      edx, r14d
       mov      rdi, gword ptr [rbp-0x30]
       call     [GameplayTags.Experiments.DirectArraySet:ValidateAndFillSorted(System.ReadOnlySpan`1[GameplayTags.RuntimeTag]):this]
       mov      rax, gword ptr [rbp-0x30]
 
G_M000_IG12:                ;; offset=0x0185
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0194
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xC77
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      r15, rax
       mov      edi, 0xCD7
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rdx, rax
       mov      rsi, r15
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String,System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG14:                ;; offset=0x01E8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 494

; Assembly listing for method GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,int):this (FullOpts)
; Emitting BLENDED_CODE for generic X64 - Unix
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 5 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rbx
       lea      rbp, [rsp+0x20]
       mov      r15, rdi
       mov      r14, rsi
       mov      ebx, edx
       mov      r13d, ecx
 
G_M000_IG02:                ;; offset=0x0018
       mov      rdi, r14
       test     rdi, rdi
       je       G_M000_IG11
       lea      rdi, bword ptr [r15+0x18]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       test     ebx, ebx
       jl       G_M000_IG12
       test     r13d, r13d
       jl       G_M000_IG13
       cmp      r13d, 2
       jg       G_M000_IG13
       mov      rdi, gword ptr [r14+0x10]
       cmp      dword ptr [rdi+0x08], 0x100000
       jg       G_M000_IG14
       mov      eax, dword ptr [rdi+0x08]
       cmp      ebx, eax
       cmovg    ebx, eax
       cmp      r13d, 2
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x006A
       test     r13d, r13d
       jne      G_M000_IG08
       cmp      dword ptr [rdi+0x08], 0
       je       G_M000_IG08
       mov      rdi, r14
       call     [GameplayTags.TagRegistry:get_WordCount():int:this]
       movsxd   rdi, eax
       shl      rdi, 3
       movsxd   rax, ebx
       shl      rax, 2
       cmp      rdi, rax
       jg       SHORT G_M000_IG08
 
G_M000_IG04:                ;; offset=0x0099
       mov      rdi, r14
       call     [GameplayTags.TagRegistry:get_WordCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rdi, r14
       call     [GameplayTags.TagRegistry:get_WordCount():int:this]
       movsxd   rsi, eax
       mov      rdi, 0x7F2D1CA0B088
       call     CORINFO_HELP_NEWARR_1_VC
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00C3
       mov      rdi, 0x7F2D1BE54D28
       mov      esi, 33
       call     CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
       mov      rdi, 0x7EED0C001F60
       mov      rax, gword ptr [rdi]
 
G_M000_IG06:                ;; offset=0x00E4
       lea      rdi, bword ptr [r15+0x10]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG07:                ;; offset=0x00F1
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00FA
       cmp      ebx, 1
       jle      SHORT G_M000_IG10
       mov      rdi, r15
       call     [GameplayTags.Experiments.DirectArraySet:get_MaxEntries():int:this]
       cmp      ebx, eax
       mov      esi, eax
       cmovle   esi, ebx
       mov      rdi, r15
       mov      edx, 1
 
G_M000_IG09:                ;; offset=0x0117
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [GameplayTags.Experiments.DirectArraySet:ReserveEntries(int,bool):this]
 
G_M000_IG10:                ;; offset=0x0125
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x012E
       mov      rdi, 0x7F2D1C029CB0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 1
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentNullException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG12:                ;; offset=0x0168
       mov      rdi, 0x7F2D1C050F48
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 570
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentOutOfRangeException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG13:                ;; offset=0x01A2
       mov      rdi, 0x7F2D1C050F48
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xD99
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentOutOfRangeException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG14:                ;; offset=0x01DC
       mov      rdi, 0x7F2D1C050F48
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 1
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      r15, rax
       mov      edi, 0xDA7
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rdx, rax
       mov      rsi, r15
       mov      rdi, rbx
       call     [System.ArgumentOutOfRangeException:.ctor(System.String,System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 561

; Assembly listing for method Probe:Work(int):long (FullOpts)
; Emitting BLENDED_CODE for generic X64 - Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 52 single block inlinees; 24 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       mov      ebx, edi
 
G_M000_IG02:                ;; offset=0x0015
       xor      r15d, r15d
       mov      rdx, 0x7EED0C001D38
       mov      rdi, gword ptr [rdx]
       test     rdi, rdi
       je       G_M000_IG38
 
G_M000_IG03:                ;; offset=0x002E
       mov      r14d, dword ptr [rdi+0x08]
       mov      edx, r14d
       cmp      edx, 14
       jg       SHORT G_M000_IG05
       lea      r13d, [rdx-0x04]
       cmp      r13d, 6
       ja       SHORT G_M000_IG04
       mov      edx, r13d
       lea      rsi, [reloc @RWD00]
       mov      esi, dword ptr [rsi+4*rdx]
       lea      rax, G_M000_IG02
       add      rsi, rax
       jmp      rsi
 
G_M000_IG04:                ;; offset=0x005D
       cmp      edx, 14
       jne      G_M000_IG38
       cmp      r14d, 8
       jbe      G_M000_IG109
       movzx    r12, word  ptr [rdi+0x1C]
       cmp      r12d, 97
       je       G_M000_IG23
       jmp      G_M000_IG09
 
G_M000_IG05:                ;; offset=0x0084
       cmp      edx, 17
       je       SHORT G_M000_IG08
       cmp      edx, 21
       jne      G_M000_IG38
       jmp      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x0097
       test     r14d, r14d
       je       G_M000_IG109
       movzx    r12, word  ptr [rdi+0x0C]
       cmp      r12d, 98
       je       G_M000_IG13
       cmp      r12d, 117
       jne      G_M000_IG38
       cmp      r14d, 5
       jne      G_M000_IG38
 
G_M000_IG07:                ;; offset=0x00C3
       mov      rdx, 0x6F0069006E0075
       xor      rdx, qword ptr [rdi+0x0C]
       mov      edi, dword ptr [rdi+0x12]
       xor      edi, 0x6E006F
       mov      esi, edi
       or       rdx, rsi
       je       G_M000_IG68
       jmp      G_M000_IG38
       align    [2 bytes for IG47]
 
G_M000_IG08:                ;; offset=0x00EC
       movzx    r12, word  ptr [rdi+0x0C]
       cmp      r12d, 102
       je       G_M000_IG18
       cmp      r12d, 116
       je       G_M000_IG16
       cmp      r12d, 117
       jne      G_M000_IG38
       jmp      G_M000_IG17
 
G_M000_IG09:                ;; offset=0x0114
       cmp      r12d, 114
       jne      G_M000_IG38
       jmp      G_M000_IG25
 
G_M000_IG10:                ;; offset=0x0123
       cmp      r14d, 7
       jne      G_M000_IG38
 
G_M000_IG11:                ;; offset=0x012D
       mov      rdx, 0x72006500750071
       xor      rdx, qword ptr [rdi+0x0C]
       mov      rsi, 0x34003600790072
       xor      rsi, qword ptr [rdi+0x12]
       or       rdx, rsi
       jne      G_M000_IG38
 
G_M000_IG12:                ;; offset=0x0152
       xor      r13d, r13d
       jmp      G_M000_IG37
 
G_M000_IG13:                ;; offset=0x015A
       cmp      r14d, 5
       jne      G_M000_IG38
 
G_M000_IG14:                ;; offset=0x0164
       mov      rdx, 0x6C006900750062
       xor      rdx, qword ptr [rdi+0x0C]
       mov      edi, dword ptr [rdi+0x12]
       xor      edi, 0x64006C
       mov      esi, edi
       or       rdx, rsi
       jne      G_M000_IG38
 
G_M000_IG15:                ;; offset=0x0186
       cmp      byte  ptr [(reloc 0x7f2d1c0232ac)], 0
       je       G_M000_IG62
       jmp      G_M000_IG56
 
G_M000_IG16:                ;; offset=0x0198
       mov      rdx, 0x7F2D96A022B0
       cmp      rdi, rdx
       je       G_M000_IG68
       add      r14d, r14d
       mov      edx, r14d
       mov      rsi, 0x7F2D96A022BC
       add      rdi, 12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,ulong):bool]
       test     eax, eax
       jne      G_M000_IG68
       jmp      G_M000_IG38
 
G_M000_IG17:                ;; offset=0x01D2
       mov      rdx, 0x7F2D96A022E8
       cmp      rdi, rdx
       je       G_M000_IG68
       lea      edx, [r14+r14]
       mov      rsi, 0x7F2D96A022F4
       add      rdi, 12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,ulong):bool]
       test     eax, eax
       jne      G_M000_IG68
       jmp      G_M000_IG38
 
G_M000_IG18:                ;; offset=0x020A
       mov      rdx, 0x7F2D96A02278
       cmp      rdi, rdx
       je       SHORT G_M000_IG19
       lea      edx, [r14+r14]
       mov      rsi, 0x7F2D96A02284
       add      rdi, 12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,ulong):bool]
       test     eax, eax
       je       G_M000_IG38
 
G_M000_IG19:                ;; offset=0x0239
       xor      r13d, r13d
       jmp      G_M000_IG96
 
G_M000_IG20:                ;; offset=0x0241
       cmp      r14d, 4
       jne      G_M000_IG38
 
G_M000_IG21:                ;; offset=0x024B
       mov      rdx, 0x790070006F0063
       cmp      qword ptr [rdi+0x0C], rdx
       jne      G_M000_IG38
 
G_M000_IG22:                ;; offset=0x025F
       xor      r12d, r12d
       jmp      G_M000_IG73
 
G_M000_IG23:                ;; offset=0x0267
       mov      rdx, 0x7F2D96A02410
       cmp      rdi, rdx
       je       SHORT G_M000_IG24
       lea      edx, [r14+r14]
       mov      rsi, 0x7F2D96A0241C
       add      rdi, 12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,ulong):bool]
       test     eax, eax
       je       G_M000_IG38
 
G_M000_IG24:                ;; offset=0x0296
       xor      r13d, r13d
       jmp      G_M000_IG77
 
G_M000_IG25:                ;; offset=0x029E
       mov      rdx, 0x7F2D96A023D8
       cmp      rdi, rdx
       je       SHORT G_M000_IG26
       lea      edx, [r14+r14]
       mov      rsi, 0x7F2D96A023E4
       add      rdi, 12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,ulong):bool]
       test     eax, eax
       je       G_M000_IG38
 
G_M000_IG26:                ;; offset=0x02CD
       xor      r12d, r12d
       jmp      G_M000_IG81
 
G_M000_IG27:                ;; offset=0x02D5
       mov      rdx, 0x7F2D96A02590
       cmp      rdi, rdx
       je       SHORT G_M000_IG28
       cmp      r14d, 10
       jne      G_M000_IG38
       lea      edx, [r14+r14]
       mov      rsi, 0x7F2D96A0259C
       add      rdi, 12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,ulong):bool]
       test     eax, eax
       je       G_M000_IG38
 
G_M000_IG28:                ;; offset=0x030E
       cmp      byte  ptr [(reloc 0x7f2d1c0232ad)], 0
       je       G_M000_IG90
       jmp      G_M000_IG83
 
G_M000_IG29:                ;; offset=0x0320
       mov      rdx, 0x7F2D96A02510
       cmp      rdi, rdx
       je       SHORT G_M000_IG30
       lea      edx, [r14+r14]
       mov      rsi, 0x7F2D96A0251C
       add      rdi, 12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,ulong):bool]
       test     eax, eax
       je       SHORT G_M000_IG38
 
G_M000_IG30:                ;; offset=0x034B
       xor      r14d, r14d
       jmp      G_M000_IG105
 
G_M000_IG31:                ;; offset=0x0353
       xor      esi, esi
 
G_M000_IG32:                ;; offset=0x0355
       mov      rcx, 0x7EED0C001CD8
       mov      r14, gword ptr [rcx]
       mov      rcx, 0x7EED0C001D10
       mov      rcx, gword ptr [rcx]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG109
       mov      edx, esi
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      rdx, gword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      gword ptr [r14+0x18], rdx
       je       SHORT G_M000_IG40
 
G_M000_IG33:                ;; offset=0x038F
       test     rdx, rdx
       jne      G_M000_IG107
 
G_M000_IG34:                ;; offset=0x0398
       xor      edx, edx
 
G_M000_IG35:                ;; offset=0x039A
       test     edx, edx
       setne    dl
       movzx    rdx, dl
       add      r15, rdx
       inc      esi
       cmp      esi, 64
       jl       SHORT G_M000_IG32
 
G_M000_IG36:                ;; offset=0x03AC
       inc      r13d
 
G_M000_IG37:                ;; offset=0x03AF
       cmp      r13d, ebx
       jl       SHORT G_M000_IG31
 
G_M000_IG38:                ;; offset=0x03B4
       xor      qword ptr [(reloc 0x7f2d1c023298)], r15
       mov      rax, r15
 
G_M000_IG39:                ;; offset=0x03BE
       add      rsp, 72
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x03CD
       mov      rdx, gword ptr [r14+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG41
       mov      r8d, ecx
       sar      r8d, 6
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG109
       mov      r8d, ecx
       sar      r8d, 6
       mov      rdx, qword ptr [rdx+8*r8+0x10]
       bt       rdx, rcx
       setb     dl
       movzx    rdx, dl
       jmp      SHORT G_M000_IG35
 
G_M000_IG41:                ;; offset=0x03FF
       mov      edx, ecx
       shr      edx, 4
       shl      edx, 16
       and      ecx, 15
       mov      r8d, 1
       shl      r8d, cl
       mov      edi, dword ptr [r14+0x24]
       cmp      edi, 1
       jne      SHORT G_M000_IG46
       mov      rcx, gword ptr [r14+0x08]
       test     rcx, rcx
       je       SHORT G_M000_IG42
       cmp      dword ptr [rcx+0x08], 0
       jbe      G_M000_IG109
       mov      edi, dword ptr [rcx+0x10]
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0434
       mov      edi, dword ptr [r14+0x20]
 
G_M000_IG43:                ;; offset=0x0438
       and      edi, -0x10000
       cmp      edi, edx
       je       SHORT G_M000_IG45
       ja       SHORT G_M000_IG44
       mov      edi, -2
       jmp      SHORT G_M000_IG53
 
G_M000_IG44:                ;; offset=0x044B
       mov      edi, -1
       jmp      SHORT G_M000_IG53
 
G_M000_IG45:                ;; offset=0x0452
       xor      edi, edi
       jmp      SHORT G_M000_IG53
 
G_M000_IG46:                ;; offset=0x0456
       xor      ecx, ecx
       dec      edi
       js       SHORT G_M000_IG51
       mov      rax, gword ptr [r14+0x08]
 
G_M000_IG47:                ;; offset=0x0460
       mov      r9d, edi
       sub      r9d, ecx
       sar      r9d, 1
       add      r9d, ecx
       mov      r10, rax
       cmp      r9d, dword ptr [r10+0x08]
       jae      G_M000_IG109
       mov      r11d, r9d
       mov      r10d, dword ptr [r10+4*r11+0x10]
       and      r10d, -0x10000
       cmp      r10d, edx
       je       SHORT G_M000_IG52
       jae      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x048F
       lea      ecx, [r9+0x01]
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0495
       lea      edi, [r9-0x01]
 
G_M000_IG50:                ;; offset=0x0499
       cmp      ecx, edi
       jle      SHORT G_M000_IG47
 
G_M000_IG51:                ;; offset=0x049D
       mov      edi, ecx
       not      edi
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x04A3
       mov      edi, r9d
 
G_M000_IG53:                ;; offset=0x04A6
       test     edi, edi
       jl       G_M000_IG34
       mov      rax, gword ptr [r14+0x08]
       test     rax, rax
       je       SHORT G_M000_IG54
       mov      rdx, rax
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG109
       mov      edi, edi
       mov      edx, dword ptr [rdx+4*rdi+0x10]
       jmp      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x04CB
       mov      edx, dword ptr [r14+0x20]
 
G_M000_IG55:                ;; offset=0x04CF
       test     edx, r8d
       setne    dl
       movzx    rdx, dl
       jmp      G_M000_IG35
 
G_M000_IG56:                ;; offset=0x04DD
       xor      r12d, r12d
       test     ebx, ebx
       jle      G_M000_IG38
 
G_M000_IG57:                ;; offset=0x04E8
       mov      rsi, 0x7EED0C001CD0
       mov      rdi, gword ptr [rsi]
       mov      rsi, 0x7EED0C001D00
       mov      rsi, gword ptr [rsi]
       test     rsi, rsi
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x0507
       xor      rsi, rsi
       xor      edx, edx
       jmp      SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x050D
       lea      rdx, bword ptr [rsi+0x10]
       mov      esi, dword ptr [rsi+0x08]
       mov      rax, rdx
       mov      edx, esi
       mov      rsi, rax
 
G_M000_IG60:                ;; offset=0x051C
       mov      r8d, dword ptr [(reloc 0x7f2d1c0232a8)]
       xor      ecx, ecx
       call     [GameplayTags.Experiments.DirectArraySet:FromUnordered(GameplayTags.TagRegistry,System.ReadOnlySpan`1[GameplayTags.RuntimeTag],int,int):GameplayTags.Experiments.DirectArraySet]
       movsxd   rdi, dword ptr [rax+0x28]
       add      r15, rdi
       mov      rdi, 0x7EED0C001CF8
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       inc      r12d
       cmp      r12d, ebx
       jl       SHORT G_M000_IG57
 
G_M000_IG61:                ;; offset=0x054C
       jmp      G_M000_IG38
 
G_M000_IG62:                ;; offset=0x0551
       xor      r14d, r14d
       test     ebx, ebx
       jle      G_M000_IG38
 
G_M000_IG63:                ;; offset=0x055C
       mov      rsi, 0x7EED0C001CD0
       mov      rdi, gword ptr [rsi]
       mov      rsi, 0x7EED0C001D00
       mov      rsi, gword ptr [rsi]
       test     rsi, rsi
       jne      SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x057B
       xor      rsi, rsi
       xor      edx, edx
       jmp      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x0581
       lea      rdx, bword ptr [rsi+0x10]
       mov      esi, dword ptr [rsi+0x08]
       mov      rax, rdx
       mov      edx, esi
       mov      rsi, rax
 
G_M000_IG66:                ;; offset=0x0590
       mov      r8d, dword ptr [(reloc 0x7f2d1c0232a8)]
       xor      ecx, ecx
       call     [GameplayTags.Experiments.DirectArraySet:FromSortedUnique(GameplayTags.TagRegistry,System.ReadOnlySpan`1[GameplayTags.RuntimeTag],int,int):GameplayTags.Experiments.DirectArraySet]
       movsxd   rdi, dword ptr [rax+0x28]
       add      r15, rdi
       mov      rdi, 0x7EED0C001CF8
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       inc      r14d
       cmp      r14d, ebx
       jl       SHORT G_M000_IG63
 
G_M000_IG67:                ;; offset=0x05C0
       jmp      G_M000_IG38
 
G_M000_IG68:                ;; offset=0x05C5
       xor      r13d, r13d
       test     ebx, ebx
       jle      G_M000_IG38
 
G_M000_IG69:                ;; offset=0x05D0
       mov      rdi, 0x7EED0C001CD8
       mov      rdi, gword ptr [rdi]
       mov      rsi, 0x7EED0C001CE0
       mov      rsi, gword ptr [rsi]
       mov      r14, 0x7EED0C001CE8
       mov      rdx, gword ptr [r14]
       call     [GameplayTags.Experiments.DirectArraySet:UnionInto(GameplayTags.Experiments.DirectArraySet,GameplayTags.Experiments.DirectArraySet,GameplayTags.Experiments.DirectArraySet)]
       mov      rdi, gword ptr [r14]
       movsxd   rdi, dword ptr [rdi+0x28]
       add      r15, rdi
       inc      r13d
       cmp      r13d, ebx
       jl       SHORT G_M000_IG69
 
G_M000_IG70:                ;; offset=0x060F
       jmp      G_M000_IG38
 
G_M000_IG71:                ;; offset=0x0614
       mov      r14, 0x7EED0C001CE8
       mov      r13, gword ptr [r14]
       mov      rdi, 0x7EED0C001CE0
       mov      rax, gword ptr [rdi]
       mov      gword ptr [rbp-0x48], rax
       cmp      byte  ptr [r13], r13b
       mov      rdi, r13
       mov      rsi, rax
       call     [GameplayTags.Experiments.DirectArraySet:Require(GameplayTags.Experiments.DirectArraySet):this]
       mov      rsi, gword ptr [rbp-0x48]
       cmp      r13, rsi
       je       SHORT G_M000_IG72
       mov      rdi, r13
       call     [GameplayTags.Experiments.DirectArraySet:CopyCore(GameplayTags.Experiments.DirectArraySet):this]
 
G_M000_IG72:                ;; offset=0x0654
       mov      rdi, gword ptr [r14]
       movsxd   rdi, dword ptr [rdi+0x28]
       add      r15, rdi
       inc      r12d
 
G_M000_IG73:                ;; offset=0x0661
       cmp      r12d, ebx
       jl       SHORT G_M000_IG71
 
G_M000_IG74:                ;; offset=0x0666
       jmp      G_M000_IG38
 
G_M000_IG75:                ;; offset=0x066B
       mov      r14, 0x7EED0C001CE8
       mov      r12, gword ptr [r14]
       mov      rdi, 0x7EED0C001CD8
       mov      rax, gword ptr [rdi]
       mov      gword ptr [rbp-0x50], rax
       cmp      byte  ptr [r12], r12b
       mov      rdi, r12
       mov      rsi, rax
       call     [GameplayTags.Experiments.DirectArraySet:Require(GameplayTags.Experiments.DirectArraySet):this]
       mov      rsi, gword ptr [rbp-0x50]
       cmp      r12, rsi
       je       SHORT G_M000_IG76
       mov      rdi, r12
       call     [GameplayTags.Experiments.DirectArraySet:CopyCore(GameplayTags.Experiments.DirectArraySet):this]
 
G_M000_IG76:                ;; offset=0x06AB
       mov      r12, gword ptr [r14]
       mov      rdi, 0x7EED0C001CE0
       mov      rax, gword ptr [rdi]
       mov      gword ptr [rbp-0x58], rax
       cmp      byte  ptr [r12], r12b
       mov      rdi, r12
       mov      rsi, rax
       call     [GameplayTags.Experiments.DirectArraySet:Require(GameplayTags.Experiments.DirectArraySet):this]
       mov      rdi, r12
       mov      rsi, gword ptr [rbp-0x58]
       call     [GameplayTags.Experiments.DirectArraySet:AppendCore(GameplayTags.Experiments.DirectArraySet):this]
       mov      rdi, gword ptr [r14]
       movsxd   rdi, dword ptr [rdi+0x28]
       add      r15, rdi
       inc      r13d
 
G_M000_IG77:                ;; offset=0x06E9
       cmp      r13d, ebx
       jl       G_M000_IG75
 
G_M000_IG78:                ;; offset=0x06F2
       jmp      G_M000_IG38
 
G_M000_IG79:                ;; offset=0x06F7
       mov      r14, 0x7EED0C001CE8
       mov      r13, gword ptr [r14]
       mov      rdi, 0x7EED0C001CD8
       mov      rax, gword ptr [rdi]
       mov      gword ptr [rbp-0x60], rax
       cmp      byte  ptr [r13], r13b
       mov      rdi, r13
       mov      rsi, rax
       call     [GameplayTags.Experiments.DirectArraySet:Require(GameplayTags.Experiments.DirectArraySet):this]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      r13, rsi
       je       SHORT G_M000_IG80
       mov      rdi, r13
       call     [GameplayTags.Experiments.DirectArraySet:CopyCore(GameplayTags.Experiments.DirectArraySet):this]
 
G_M000_IG80:                ;; offset=0x0737
       mov      rdi, gword ptr [r14]
       mov      rsi, 0x7EED0C001CE0
       mov      rsi, gword ptr [rsi]
       cmp      dword ptr [rdi], edi
       call     [GameplayTags.Experiments.DirectArraySet:RemoveTags(GameplayTags.Experiments.DirectArraySet):this]
       mov      rdi, gword ptr [r14]
       movsxd   rdi, dword ptr [rdi+0x28]
       add      r15, rdi
       inc      r12d
 
G_M000_IG81:                ;; offset=0x075C
       cmp      r12d, ebx
       jl       SHORT G_M000_IG79
 
G_M000_IG82:                ;; offset=0x0761
       jmp      G_M000_IG38
 
G_M000_IG83:                ;; offset=0x0766
       xor      r13d, r13d
       test     ebx, ebx
       jle      G_M000_IG38
 
G_M000_IG84:                ;; offset=0x0771
       mov      r14, 0x7EED0C001CE8
       mov      rdi, gword ptr [r14]
       mov      rsi, 0x7EED0C001CC8
       mov      rsi, gword ptr [rsi]
       mov      rax, gword ptr [rsi+0x08]
       mov      esi, dword ptr [rsi+0x10]
       cmp      byte  ptr [rdi], dil
       test     rax, rax
       je       SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x079A
       mov      rcx, gword ptr [rdi+0x18]
       cmp      byte  ptr [rcx], cl
       cmp      rcx, rax
       jne      G_M000_IG108
       call     [GameplayTags.Experiments.DirectArraySet:AddId(int):bool:this]
 
G_M000_IG86:                ;; offset=0x07AF
       mov      r12, gword ptr [r14]
       mov      rdi, 0x7EED0C001CF0
       mov      rax, gword ptr [rdi]
       mov      gword ptr [rbp-0x68], rax
       cmp      byte  ptr [r12], r12b
       mov      rdi, r12
       mov      rsi, rax
       call     [GameplayTags.Experiments.DirectArraySet:Require(GameplayTags.Experiments.DirectArraySet):this]
       mov      rsi, gword ptr [rbp-0x68]
       cmp      r12, rsi
       je       SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x07DC
       mov      rdi, r12
       call     [GameplayTags.Experiments.DirectArraySet:CopyCore(GameplayTags.Experiments.DirectArraySet):this]
 
G_M000_IG88:                ;; offset=0x07E5
       mov      rdi, gword ptr [r14]
       movsxd   rdi, dword ptr [rdi+0x28]
       add      r15, rdi
       inc      r13d
       cmp      r13d, ebx
       jl       G_M000_IG84
 
G_M000_IG89:                ;; offset=0x07FB
       jmp      G_M000_IG38
 
G_M000_IG90:                ;; offset=0x0800
       mov      r14, 0x7EED0C001CE8
       mov      rdi, gword ptr [r14]
       cmp      dword ptr [rdi], edi
       call     [GameplayTags.Experiments.DirectArraySet:Clear():this]
       xor      r13d, r13d
       test     ebx, ebx
       jle      G_M000_IG38
 
G_M000_IG91:                ;; offset=0x0820
       mov      r12, gword ptr [r14]
       mov      rdi, 0x7EED0C001CF0
       mov      rax, gword ptr [rdi]
       mov      gword ptr [rbp-0x70], rax
       cmp      byte  ptr [r12], r12b
       mov      rdi, r12
       mov      rsi, rax
       call     [GameplayTags.Experiments.DirectArraySet:Require(GameplayTags.Experiments.DirectArraySet):this]
       mov      rsi, gword ptr [rbp-0x70]
       cmp      r12, rsi
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x084D
       mov      rdi, r12
       call     [GameplayTags.Experiments.DirectArraySet:CopyCore(GameplayTags.Experiments.DirectArraySet):this]
 
G_M000_IG93:                ;; offset=0x0856
       mov      rdi, gword ptr [r14]
       movsxd   rdi, dword ptr [rdi+0x28]
       add      r15, rdi
       inc      r13d
       cmp      r13d, ebx
       jl       SHORT G_M000_IG91
 
G_M000_IG94:                ;; offset=0x0868
       jmp      G_M000_IG38
 
G_M000_IG95:                ;; offset=0x086D
       mov      rdi, 0x7F2D1C05F5C8
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rsi, 0x7EED0C001CD0
       mov      rsi, gword ptr [rsi]
       mov      rdi, r14
       xor      edx, edx
       mov      ecx, 1
       call     [GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,int):this]
       mov      rdi, 0x7EED0C001CD8
       mov      rdi, gword ptr [rdi]
       mov      rsi, 0x7EED0C001CE0
       mov      rsi, gword ptr [rsi]
       mov      rdx, r14
       call     [GameplayTags.Experiments.DirectArraySet:UnionInto(GameplayTags.Experiments.DirectArraySet,GameplayTags.Experiments.DirectArraySet,GameplayTags.Experiments.DirectArraySet)]
       movsxd   rdi, dword ptr [r14+0x28]
       add      r15, rdi
       mov      rdi, 0x7EED0C001CF8
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       inc      r13d
 
G_M000_IG96:                ;; offset=0x08DB
       cmp      r13d, ebx
       jl       SHORT G_M000_IG95
 
G_M000_IG97:                ;; offset=0x08E0
       jmp      G_M000_IG38
 
G_M000_IG98:                ;; offset=0x08E5
       mov      rsi, 0x7EED0C001CD0
       mov      rdi, gword ptr [rsi]
       mov      rsi, 0x7EED0C001D00
       mov      rsi, gword ptr [rsi]
       test     rsi, rsi
       jne      SHORT G_M000_IG99
       xor      rsi, rsi
       xor      edx, edx
       jmp      SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x090A
       lea      rdx, bword ptr [rsi+0x10]
       mov      esi, dword ptr [rsi+0x08]
       mov      rax, rdx
       mov      edx, esi
       mov      rsi, rax
 
G_M000_IG100:                ;; offset=0x0919
       mov      r8d, dword ptr [(reloc 0x7f2d1c0232a8)]
       xor      ecx, ecx
       call     [GameplayTags.Experiments.DirectArraySet:FromUnordered(GameplayTags.TagRegistry,System.ReadOnlySpan`1[GameplayTags.RuntimeTag],int,int):GameplayTags.Experiments.DirectArraySet]
       mov      r13, rax
       mov      rsi, 0x7EED0C001CD0
       mov      rdi, gword ptr [rsi]
       mov      rsi, 0x7EED0C001D08
       mov      rsi, gword ptr [rsi]
       test     rsi, rsi
       jne      SHORT G_M000_IG101
       xor      rsi, rsi
       xor      edx, edx
       jmp      SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0950
       lea      rdx, bword ptr [rsi+0x10]
       mov      esi, dword ptr [rsi+0x08]
       mov      rax, rdx
       mov      edx, esi
       mov      rsi, rax
 
G_M000_IG102:                ;; offset=0x095F
       mov      r8d, dword ptr [(reloc 0x7f2d1c0232a8)]
       xor      ecx, ecx
       call     [GameplayTags.Experiments.DirectArraySet:FromUnordered(GameplayTags.TagRegistry,System.ReadOnlySpan`1[GameplayTags.RuntimeTag],int,int):GameplayTags.Experiments.DirectArraySet]
       mov      r12, rax
       mov      rdi, 0x7F2D1C05F5C8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x40], rax
       mov      rdx, 0x7EED0C001D00
       mov      rdx, gword ptr [rdx]
       mov      edx, dword ptr [rdx+0x08]
       mov      rsi, 0x7EED0C001D08
       mov      rsi, gword ptr [rsi]
       add      edx, dword ptr [rsi+0x08]
       mov      rsi, 0x7EED0C001CD0
       mov      rsi, gword ptr [rsi]
       mov      ecx, dword ptr [(reloc 0x7f2d1c0232a8)]
       mov      rdi, rax
       call     [GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,int):this]
       mov      rax, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x38], rax
       xor      ecx, ecx
       mov      dword ptr [rbp-0x2C], ecx
 
G_M000_IG103:                ;; offset=0x09CD
       mov      rdi, r13
       mov      rsi, r12
       mov      rdx, rax
       call     [GameplayTags.Experiments.DirectArraySet:UnionInto(GameplayTags.Experiments.DirectArraySet,GameplayTags.Experiments.DirectArraySet,GameplayTags.Experiments.DirectArraySet)]
       mov      rax, gword ptr [rbp-0x38]
       movsxd   rdi, dword ptr [rax+0x28]
       add      r15, rdi
       mov      ecx, dword ptr [rbp-0x2C]
       inc      ecx
       cmp      ecx, 64
       mov      dword ptr [rbp-0x2C], ecx
       jl       SHORT G_M000_IG103
 
G_M000_IG104:                ;; offset=0x09F4
       mov      rdi, 0x7EED0C001CF8
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       inc      r14d
 
G_M000_IG105:                ;; offset=0x0A09
       cmp      r14d, ebx
       jl       G_M000_IG98
 
G_M000_IG106:                ;; offset=0x0A12
       jmp      G_M000_IG38
 
G_M000_IG107:                ;; offset=0x0A17
       mov      rdi, gword ptr [r14+0x18]
       cmp      byte  ptr [rdi], dil
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG108:                ;; offset=0x0A58
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG109:                ;; offset=0x0A92
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	0000022Ch ; case G_M000_IG20
       	dd	00000082h ; case G_M000_IG06
       	dd	0000039Fh ; case G_M000_IG38
       	dd	0000010Eh ; case G_M000_IG10
       	dd	0000039Fh ; case G_M000_IG38
       	dd	0000039Fh ; case G_M000_IG38
       	dd	000002C0h ; case G_M000_IG27

; Total bytes of code 2712

; Assembly listing for method GameplayTags.Experiments.DirectArraySet:.ctor(GameplayTags.TagRegistry,int,bool):this (FullOpts)
; Emitting BLENDED_CODE for generic X64 - Unix
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 2 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rbx
       lea      rbp, [rsp+0x20]
       mov      rbx, rdi
       mov      r15, rsi
       mov      r14d, edx
       mov      r13d, ecx
 
G_M000_IG02:                ;; offset=0x0019
       lea      rdi, bword ptr [rbx+0x18]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       test     r13b, r13b
       je       SHORT G_M000_IG07
 
G_M000_IG03:                ;; offset=0x002A
       mov      rdi, r15
       cmp      dword ptr [rdi], edi
       call     [GameplayTags.TagRegistry:get_WordCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rdi, r15
       call     [GameplayTags.TagRegistry:get_WordCount():int:this]
       movsxd   rsi, eax
       mov      rdi, 0x7F2D1CA0B088
       call     CORINFO_HELP_NEWARR_1_VC
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0056
       mov      rdi, 0x7F2D1BE54D28
       mov      esi, 33
       call     CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
       mov      rdi, 0x7EED0C001F60
       mov      rax, gword ptr [rdi]
 
G_M000_IG05:                ;; offset=0x0077
       lea      rdi, bword ptr [rbx+0x10]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG06:                ;; offset=0x0084
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x008D
       mov      rdi, rbx
       call     [GameplayTags.Experiments.DirectArraySet:get_MaxEntries():int:this]
       cmp      r14d, eax
       cmovg    r14d, eax
       cmp      r14d, 1
       jle      SHORT G_M000_IG08
       movsxd   rsi, r14d
       mov      rdi, 0x7F2D1C8B9760
       call     CORINFO_HELP_NEWARR_1_VC
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG08:                ;; offset=0x00C1
       nop      
 
G_M000_IG09:                ;; offset=0x00C2
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
; Total bytes of code 203

; Assembly listing for method GameplayTags.Experiments.DirectArraySet:ValidateAndFillSorted(System.ReadOnlySpan`1[GameplayTags.RuntimeTag]):this (FullOpts)
; Emitting BLENDED_CODE for generic X64 - Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rbx
       push     rax
       lea      rbp, [rsp+0x20]
 
G_M000_IG02:                ;; offset=0x000C
       mov      eax, edx
       mov      r8d, -1
       mov      r9, gword ptr [rdi+0x10]
       test     r9, r9
       je       G_M000_IG11
 
G_M000_IG03:                ;; offset=0x0021
       mov      r10d, -1
       xor      r11d, r11d
       xor      ebx, ebx
       test     edx, edx
       jle      SHORT G_M000_IG08
       align    [0 bytes for IG04]
 
G_M000_IG04:                ;; offset=0x0030
       mov      ecx, ebx
       shl      rcx, 4
       add      rcx, rsi
       mov      r15, gword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      r15, gword ptr [rdi+0x18]
       jne      G_M000_IG21
       cmp      ecx, r8d
       jle      G_M000_IG22
       mov      r8d, ecx
       mov      ecx, r8d
       sar      ecx, 6
       cmp      ecx, r10d
       je       SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x0060
       test     r10d, r10d
       jl       SHORT G_M000_IG06
       cmp      r10d, dword ptr [r9+0x08]
       jae      G_M000_IG25
       mov      r10d, r10d
       mov      qword ptr [r9+8*r10+0x10], r11
 
G_M000_IG06:                ;; offset=0x0077
       mov      r10d, ecx
       xor      r11d, r11d
 
G_M000_IG07:                ;; offset=0x007D
       mov      r15d, 1
       mov      ecx, r8d
       shl      r15, cl
       or       r11, r15
       inc      ebx
       cmp      ebx, edx
       jl       SHORT G_M000_IG04
 
G_M000_IG08:                ;; offset=0x0092
       cmp      r10d, dword ptr [r9+0x08]
       jae      G_M000_IG25
       mov      edx, r10d
       mov      qword ptr [r9+8*rdx+0x10], r11
 
G_M000_IG09:                ;; offset=0x00A4
       mov      dword ptr [rdi+0x28], eax
 
G_M000_IG10:                ;; offset=0x00A7
       add      rsp, 8
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x00B2
       mov      r9, gword ptr [rdi+0x08]
       test     r9, r9
       jne      SHORT G_M000_IG14
       xor      r9d, r9d
       xor      r10d, r10d
       test     edx, edx
       jle      SHORT G_M000_IG13
       align    [7 bytes for IG12]
 
G_M000_IG12:                ;; offset=0x00D0
       mov      ecx, r10d
       shl      rcx, 4
       add      rcx, rsi
       mov      r11, gword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      r11, gword ptr [rdi+0x18]
       jne      G_M000_IG23
       cmp      ecx, r8d
       jle      G_M000_IG24
       mov      r8d, ecx
       mov      ecx, r8d
       and      ecx, 15
       mov      r11d, 1
       shl      r11d, cl
       or       r9d, r11d
       inc      r10d
       cmp      r10d, edx
       jl       SHORT G_M000_IG12
 
G_M000_IG13:                ;; offset=0x0110
       shr      r8d, 4
       shl      r8d, 16
       or       r8d, r9d
       mov      dword ptr [rdi+0x20], r8d
       mov      dword ptr [rdi+0x24], 1
       jmp      G_M000_IG09
       align    [0 bytes for IG15]
 
G_M000_IG14:                ;; offset=0x012B
       xor      r10d, r10d
       xor      r11d, r11d
       xor      ebx, ebx
       xor      r15d, r15d
       test     edx, edx
       jle      SHORT G_M000_IG18
 
G_M000_IG15:                ;; offset=0x013A
       mov      ecx, r15d
       shl      rcx, 4
       add      rcx, rsi
       mov      r14, gword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      r14, gword ptr [rdi+0x18]
       jne      G_M000_IG19
       cmp      ecx, r8d
       jle      G_M000_IG20
       mov      r8d, ecx
       mov      ecx, r8d
       shr      ecx, 4
       shl      ecx, 16
       cmp      ecx, r10d
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x016E
       test     r11d, r11d
       je       SHORT G_M000_IG17
       lea      r14d, [rbx+0x01]
       cmp      ebx, dword ptr [r9+0x08]
       jae      G_M000_IG25
       mov      ebx, ebx
       or       r11d, r10d
       mov      dword ptr [r9+4*rbx+0x10], r11d
       xor      r11d, r11d
       mov      ebx, r14d
 
G_M000_IG17:                ;; offset=0x0191
       mov      r10d, ecx
       mov      ecx, r8d
       and      ecx, 15
       mov      r14d, 1
       shl      r14d, cl
       or       r11d, r14d
       inc      r15d
       cmp      r15d, edx
       jl       SHORT G_M000_IG15
 
G_M000_IG18:                ;; offset=0x01AE
       mov      ecx, ebx
       lea      ebx, [rcx+0x01]
       cmp      ecx, dword ptr [r9+0x08]
       jae      G_M000_IG25
       mov      edx, r10d
       or       edx, r11d
       mov      dword ptr [r9+4*rcx+0x10], edx
       mov      dword ptr [rdi+0x24], ebx
       jmp      G_M000_IG09
 
G_M000_IG19:                ;; offset=0x01D0
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xC77
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      r15, rax
       mov      edi, 0xCD7
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rdx, rax
       mov      rsi, r15
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String,System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG20:                ;; offset=0x0224
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xD3D
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      r15, rax
       mov      edi, 0xCD7
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rdx, rax
       mov      rsi, r15
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String,System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG21:                ;; offset=0x0278
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xC77
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      r15, rax
       mov      edi, 0xCD7
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rdx, rax
       mov      rsi, r15
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String,System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG22:                ;; offset=0x02CC
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xD3D
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      r15, rax
       mov      edi, 0xCD7
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rdx, rax
       mov      rsi, r15
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String,System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG23:                ;; offset=0x0320
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xC77
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      r15, rax
       mov      edi, 0xCD7
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rdx, rax
       mov      rsi, r15
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String,System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG24:                ;; offset=0x0374
       mov      rdi, 0x7F2D1BFCE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xD3D
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      r15, rax
       mov      edi, 0xCD7
       mov      rsi, 0x7F2D1C025430
       call     CORINFO_HELP_STRCNS
       mov      rdx, rax
       mov      rsi, r15
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String,System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG25:                ;; offset=0x03C8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 974

; Assembly listing for method System.Reflection.Emit.SignatureHelper:AddOneArgTypeHelperWorker(System.Type,bool):this (FullOpts)
; Emitting BLENDED_CODE for generic X64 - Unix
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 37 single block inlinees; 17 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       push     rax
       lea      rbp, [rsp+0x30]
       mov      rbx, rdi
       mov      r15, rsi
       mov      r14d, edx
 
G_M000_IG02:                ;; offset=0x0019
       mov      rdi, r15
       mov      r13, qword ptr [r15]
       mov      r12, qword ptr [r13+0x58]
       call     [r12+0x30]System.Type:get_IsGenericParameter():bool:this
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0030
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x50]
       call     [rax+0x38]System.Type:get_DeclaringMethod():System.Reflection.MethodBase:this
       test     rax, rax
       je       SHORT G_M000_IG05
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG04
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG04:                ;; offset=0x0064
       mov      rsi, gword ptr [rbx+0x08]
       mov      edi, dword ptr [rbx+0x18]
       lea      eax, [rdi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rsi+rdi+0x10], 30
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x0081
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG06
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG06:                ;; offset=0x00A6
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 19
 
G_M000_IG07:                ;; offset=0x00C1
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x70]
       call     [rax]System.Type:get_GenericParameterPosition():int:this
       mov      esi, eax
       mov      rdi, rbx
 
G_M000_IG08:                ;; offset=0x00CF
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddData(int):this]
 
G_M000_IG09:                ;; offset=0x00E3
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x60]
       mov      qword ptr [rbp-0x30], rax
       call     [rax+0x08]System.Type:get_IsGenericType():bool:this
       test     eax, eax
       je       G_M000_IG15
 
G_M000_IG10:                ;; offset=0x00F9
       mov      rdi, r15
       mov      rax, qword ptr [rbp-0x30]
       call     [rax+0x10]System.Type:get_IsGenericTypeDefinition():bool:this
       test     eax, eax
       je       SHORT G_M000_IG11
       test     r14b, r14b
       jne      G_M000_IG15
 
G_M000_IG11:                ;; offset=0x0110
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG12
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG12:                ;; offset=0x0135
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 21
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x18]System.Type:GetGenericTypeDefinition():System.Type:this
       mov      rsi, rax
       mov      rdi, rbx
       mov      edx, 1
       call     [System.Reflection.Emit.SignatureHelper:AddOneArgTypeHelperWorker(System.Type,bool):this]
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x28]System.Type:GetGenericArguments():System.Type[]:this
       mov      r15, rax
       mov      r13d, dword ptr [r15+0x08]
       mov      esi, r13d
       mov      rdi, rbx
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       xor      r12d, r12d
       test     r13d, r13d
       jle      G_M000_IG61
 
G_M000_IG13:                ;; offset=0x0194
       mov      esi, r12d
       mov      rsi, gword ptr [r15+8*rsi+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [System.Reflection.Emit.SignatureHelper:AddOneArgTypeHelperWorker(System.Type,bool):this]
       inc      r12d
       cmp      r13d, r12d
       jg       SHORT G_M000_IG13
 
G_M000_IG14:                ;; offset=0x01AF
       jmp      G_M000_IG61
 
G_M000_IG15:                ;; offset=0x01B4
       mov      r14, r15
       mov      rdi, 0x7F2D1CEADC88
       cmp      r13, rdi
       jne      G_M000_IG25
 
G_M000_IG16:                ;; offset=0x01CA
       mov      rdi, gword ptr [r14+0x10]
       mov      rsi, gword ptr [rbx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Reflection.Emit.RuntimeModuleBuilder:Equals(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG18
       cmp      byte  ptr [r14+0x9A], 0
       je       SHORT G_M000_IG17
       mov      rdi, r14
       call     [System.Reflection.Emit.RuntimeTypeBuilder:ThrowIfCreated():this]
 
G_M000_IG17:                ;; offset=0x01F1
       mov      r12d, dword ptr [r14+0x78]
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x01F7
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, r15
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x68]
       call     [rax+0x20]System.Reflection.Emit.ModuleBuilder:GetTypeMetadataToken(System.Type):int:this
       mov      r12d, eax
 
G_M000_IG19:                ;; offset=0x020B
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x78]
       call     [rax+0x08]System.Type:IsValueTypeImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG20
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG20:                ;; offset=0x023E
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 17
       mov      rdi, rbx
       mov      esi, r12d
 
G_M000_IG21:                ;; offset=0x025F
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG22:                ;; offset=0x0273
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG23
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG23:                ;; offset=0x0298
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 18
       mov      rdi, rbx
       mov      esi, r12d
 
G_M000_IG24:                ;; offset=0x02B9
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG25:                ;; offset=0x02CD
       mov      rdi, r15
       mov      rsi, 0x7F2D1CEAE8C8
       cmp      r13, rsi
       jne      G_M000_IG35
 
G_M000_IG26:                ;; offset=0x02E3
       mov      r12, gword ptr [rdi+0x08]
       mov      rdi, gword ptr [r12+0x10]
       mov      rsi, gword ptr [rbx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Reflection.Emit.RuntimeModuleBuilder:Equals(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG28
       cmp      byte  ptr [r12+0x9A], 0
       je       SHORT G_M000_IG27
       mov      rdi, r12
       call     [System.Reflection.Emit.RuntimeTypeBuilder:ThrowIfCreated():this]
 
G_M000_IG27:                ;; offset=0x0310
       mov      r14d, dword ptr [r12+0x78]
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0317
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, r15
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x68]
       call     [rax+0x20]System.Reflection.Emit.ModuleBuilder:GetTypeMetadataToken(System.Type):int:this
       mov      r14d, eax
 
G_M000_IG29:                ;; offset=0x032B
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x78]
       call     [rax+0x08]System.Type:IsValueTypeImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG32
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG30
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG30:                ;; offset=0x035E
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 17
       mov      rdi, rbx
       mov      esi, r14d
 
G_M000_IG31:                ;; offset=0x037F
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG32:                ;; offset=0x0393
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG33
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG33:                ;; offset=0x03B8
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 18
       mov      rdi, rbx
       mov      esi, r14d
 
G_M000_IG34:                ;; offset=0x03D9
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG35:                ;; offset=0x03ED
       mov      rdi, r15
       call     [r12+0x18]System.Type:IsByRefImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG39
 
G_M000_IG36:                ;; offset=0x03F9
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG37
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG37:                ;; offset=0x041E
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 16
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x08]System.Type:GetElementType():System.Type:this
       mov      r15, rax
 
G_M000_IG38:                ;; offset=0x0446
       xor      r14d, r14d
       jmp      G_M000_IG02
 
G_M000_IG39:                ;; offset=0x044E
       mov      rdi, r15
       call     [r12+0x20]System.Type:IsPointerImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG42
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0468
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG41:                ;; offset=0x0483
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 15
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x08]System.Type:GetElementType():System.Type:this
       mov      r15, rax
       jmp      SHORT G_M000_IG38
 
G_M000_IG42:                ;; offset=0x04AD
       mov      rdi, r15
       call     [r12+0x10]System.Type:IsArrayImpl():bool:this
       test     eax, eax
       je       G_M000_IG49
       mov      rdi, r15
       mov      r14, qword ptr [rbp-0x30]
       call     [r14+0x18]System.Type:get_IsSZArray():bool:this
       test     eax, eax
       je       SHORT G_M000_IG45
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x04DA
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG44:                ;; offset=0x04F5
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 29
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x08]System.Type:GetElementType():System.Type:this
       mov      r15, rax
       jmp      G_M000_IG38
 
G_M000_IG45:                ;; offset=0x0522
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG46
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG46:                ;; offset=0x054B
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 20
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x08]System.Type:GetElementType():System.Type:this
       mov      rsi, rax
       mov      rdi, rbx
       xor      edx, edx
       call     [System.Reflection.Emit.SignatureHelper:AddOneArgTypeHelperWorker(System.Type,bool):this]
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x10]System.Type:GetArrayRank():int:this
       mov      r13d, eax
       mov      rdi, rbx
       mov      esi, r13d
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       mov      rdi, rbx
       xor      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       mov      rdi, rbx
       mov      esi, r13d
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       xor      r15d, r15d
       test     r13d, r13d
       jle      G_M000_IG61
 
G_M000_IG47:                ;; offset=0x05BA
       mov      rdi, rbx
       xor      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       inc      r15d
       cmp      r15d, r13d
       jl       SHORT G_M000_IG47
 
G_M000_IG48:                ;; offset=0x05CD
       jmp      G_M000_IG61
 
G_M000_IG49:                ;; offset=0x05D2
       mov      r14d, 34
       mov      rdi, 0x7F2D1BE59C70
       cmp      r13, rdi
       jne      SHORT G_M000_IG51
       mov      rdi, r15
       call     System.RuntimeTypeHandle:GetCorElementType(System.RuntimeType):ubyte
       mov      r14d, eax
       cmp      r14d, 18
       jne      SHORT G_M000_IG51
       mov      rdi, 0x7F2D96A00B70
       cmp      r15, rdi
       jne      SHORT G_M000_IG50
       mov      r14d, 28
       jmp      SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x060F
       mov      rdi, 0x7F2D96A00020
       mov      eax, 14
       cmp      r15, rdi
       cmove    r14d, eax
 
G_M000_IG51:                ;; offset=0x0625
       mov      edi, r14d
       call     [System.Reflection.Emit.SignatureHelper:IsSimpleType(ubyte):bool]
       test     eax, eax
       je       SHORT G_M000_IG53
       mov      rdi, rbx
       mov      esi, r14d
 
G_M000_IG52:                ;; offset=0x0638
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddElementType(ubyte):this]
 
G_M000_IG53:                ;; offset=0x064C
       cmp      gword ptr [rbx+0x10], 0
       jne      SHORT G_M000_IG55
       mov      rdi, rbx
       mov      rsi, r15
 
G_M000_IG54:                ;; offset=0x0659
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:InternalAddRuntimeType(System.Type):this]
 
G_M000_IG55:                ;; offset=0x066D
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x78]
       call     [rax+0x08]System.Type:IsValueTypeImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG58
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, r15
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x68]
       call     [rax+0x20]System.Reflection.Emit.ModuleBuilder:GetTypeMetadataToken(System.Type):int:this
       mov      r15d, eax
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG56
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG56:                ;; offset=0x06B4
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 17
       mov      rdi, rbx
       mov      esi, r15d
 
G_M000_IG57:                ;; offset=0x06D5
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG58:                ;; offset=0x06E9
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, r15
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x68]
       call     [rax+0x20]System.Reflection.Emit.ModuleBuilder:GetTypeMetadataToken(System.Type):int:this
       mov      r15d, eax
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG59
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG59:                ;; offset=0x0722
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      SHORT G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 18
       mov      rdi, rbx
       mov      esi, r15d
 
G_M000_IG60:                ;; offset=0x073F
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG61:                ;; offset=0x0753
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG62:                ;; offset=0x0762
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1896

