# Selected-v3 Runtime correctness gate

The hardware-gated count revision passes the focused managed correctness gate. All 36 processes completed successfully, using separately built actual Runtime DLLs. No original Runtime suite was repeated because the only production change from the previously admitted revision is the dispatch inside DirectArraySet.Pop32 and Pop64.

Selected snapshot: `25152f9ceb31dfff5408aed458859f55deb658273fae3a7d9cfff998da6ea9ad`.
Integrated source proof: `a979f18f11d5ed693c0d49496bf7e635ac3a68de538e3dab7f56c50215a0419a`.

## Scope and results

Each of normal net8, checked net8 and actual checked netstandard2.1 was exercised by separate net8 test hosts on default and hardware-disabled backends. Each process checked its loaded Runtime assembly name, framework and SHA256. Intended and deployed dependency hashes were checked before execution; compiler inputs were checked before and after execution. Production libraries use no experimental defines and no Audit dependencies. Standard compiles without unsafe blocks.

Per applicable process:

- 527,886 independent Pop32/Pop64 oracle checks, including every low-16 pattern in multiple positions and 100,000 random values of each width
- 4,071,012 independent semantic checks across 3,738 cases, including mixed layouts, aliases, capacities, foreign/default handles, duplicates, boundaries and prepared zero-allocation operations
- 121 shared-handle interop checks
- 94,464 mutation, hit/miss and inactive-tail bridge checks, with zero prepared allocation
- 3,931 injected copy allocation failures plus 3,873 normal copy configurations
- 292 injected mixed-union allocation failures plus 140 normal configurations

Fault suites compile separate Runtime DLL copies with exactly one `CopyFault.Before()` insertion before the Entry-array allocation and a test-only internal hook. Their hashes and instrumentation proofs are retained separately. Fault hosts contain only fixture code and reference those DLLs. Every fault state is valid, source ownership is preserved, and retry/reuse succeeds. Hooks do not enter the clean performance DLL.

## Source review and compatibility

Only `Runtime/DirectArraySet.cs` differs from admitted v2, and its diff is confined to the two count helpers. The net8 path calls BitOperations only when the corresponding x86 POPCNT support or ARM64 AdvSimd support is available; otherwise it executes the original unchecked inline SWAR body. Pop64 correctly requires the x64 POPCNT feature rather than only the 32-bit feature. Standard preprocessing retains the original SWAR code.

An actual metadata comparison confirms all 352 checked Standard method bodies, method/local signatures, stack metadata and exception regions are identical to admitted v2. The raw comparator report retains its original hardcoded description mentioning ordinary unchecked builds; the admission file explicitly records that these two supplied inputs are checked Standard libraries. The comparison itself is exact and passed.

Native Runtime tests and public documentation consumers still compile. Runtime, Editor, facade and test hosts remain separate assemblies. The existing bridge and three legacy checked-guard repairs are byte-identical to v2.

## Clean Runtime identities

| Build | SHA256 |
|---|---|
| Normal net8 | `546555352be5e6142b98b84648a55518c75c89af8c5d11e703cd8ea54bc058b8` |
| Checked net8 | `f8db75bbe14cd39362ebc544b7603941c89cb178de2c0903938499d187755169` |
| Checked Standard2.1 | `92e17670b84fa86f3ceb9a4283794a0f4f05ede5a5959a35a577e31121c70757` |

The normal DLL is `integration-results/runtime-v3-net8/runtime/bin/GameplayTags.dll`. Its shared normal facade is unchanged. Full source, reference, host and fault-library bindings are in `runtime-v3-admission.json` and the six `integration-results/runtime-v3-*` result directories. The reusable actual-library fault runner is `integration_faults.py`.

This establishes managed correctness on x64. ARM64 dispatch was source-reviewed and compiled but not executed. Unity, Mono, IL2CPP, Burst and device execution remain untested. v2 measurements and proofs remain preserved; v3 performance requires its separately bound measurements.
