; Assembly listing for method GameplayTags.Experiments.DirectArraySet:AnyInDenseRange(ulong[],int,int):bool (FullOpts)
; Emitting BLENDED_CODE for X64 with AVX512 - Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       mov      rbp, rsp
 
G_M000_IG02:                ;; offset=0x0004
       mov      ecx, esi
       sar      ecx, 6
       lea      r8d, [rdx-0x01]
       sar      r8d, 6
       mov      rax, -1
       shlx     rsi, rax, rsi
       test     dl, 63
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0025
       mov      eax, 1
       shlx     rdx, rax, rdx
       dec      rdx
       jmp      SHORT G_M000_IG05
       align    [0 bytes for IG11]
 
G_M000_IG04:                ;; offset=0x0034
       mov      rdx, -1
 
G_M000_IG05:                ;; offset=0x003E
       cmp      ecx, r8d
       jne      SHORT G_M000_IG08
 
G_M000_IG06:                ;; offset=0x0043
       mov      r9d, dword ptr [rdi+0x08]
       cmp      ecx, r9d
       jae      G_M000_IG18
       mov      eax, ecx
       and      rsi, qword ptr [rdi+8*rax+0x10]
       xor      eax, eax
       test     rsi, rdx
       setne    al
 
G_M000_IG07:                ;; offset=0x005F
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0061
       mov      r9d, dword ptr [rdi+0x08]
       cmp      ecx, r9d
       jae      SHORT G_M000_IG18
       mov      eax, ecx
       test     qword ptr [rdi+8*rax+0x10], rsi
       je       SHORT G_M000_IG10
       mov      eax, 1
 
G_M000_IG09:                ;; offset=0x0078
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x007A
       inc      ecx
       cmp      ecx, r8d
       jge      SHORT G_M000_IG14
       mov      eax, ecx
       or       eax, r8d
       jl       SHORT G_M000_IG13
       cmp      r9d, r8d
       jl       SHORT G_M000_IG13
 
G_M000_IG11:                ;; offset=0x008D
       mov      eax, ecx
       cmp      qword ptr [rdi+8*rax+0x10], 0
       jne      SHORT G_M000_IG16
       inc      ecx
       cmp      ecx, r8d
       jl       SHORT G_M000_IG11
 
G_M000_IG12:                ;; offset=0x009E
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x00A0
       cmp      ecx, r9d
       jae      SHORT G_M000_IG18
       mov      eax, ecx
       cmp      qword ptr [rdi+8*rax+0x10], 0
       jne      SHORT G_M000_IG16
       inc      ecx
       cmp      ecx, r8d
       jl       SHORT G_M000_IG13
 
G_M000_IG14:                ;; offset=0x00B6
       cmp      r8d, r9d
       jae      SHORT G_M000_IG18
       mov      eax, r8d
       test     qword ptr [rdi+8*rax+0x10], rdx
       setne    al
       movzx    rax, al
 
G_M000_IG15:                ;; offset=0x00C9
       pop      rbp
       ret      
 
G_M000_IG16:                ;; offset=0x00CB
       mov      eax, 1
 
G_M000_IG17:                ;; offset=0x00D0
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x00D2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 216

