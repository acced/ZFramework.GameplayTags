; Assembly listing for method GameplayTags.RuntimeTagSet:AnyInRange(int,int):bool:this (FullOpts)
; Emitting BLENDED_CODE for X64 with AVX512 - Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rbx
       push     rax
       lea      rbp, [rsp+0x20]
       mov      rbx, rdi
       mov      r15d, edx
 
G_M000_IG02:                ;; offset=0x0012
       cmp      dword ptr [rbx+0x20], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0018
       cmp      esi, r15d
       je       SHORT G_M000_IG04
       mov      r14, gword ptr [rbx+0x10]
       test     r14, r14
       jne      SHORT G_M000_IG06
       mov      rdi, rbx
       call     [GameplayTags.RuntimeTagSet:IndexOf(int):int:this]
       test     eax, eax
       jge      G_M000_IG14
       not      eax
       cmp      eax, dword ptr [rbx+0x20]
       jge      SHORT G_M000_IG04
       mov      rcx, gword ptr [rbx+0x08]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG16
       cmp      dword ptr [rcx+4*rax+0x10], r15d
       setl     cl
       movzx    rcx, cl
       jmp      G_M000_IG12
       align    [4 bytes for IG10]
 
G_M000_IG04:                ;; offset=0x005F
       xor      eax, eax
 
G_M000_IG05:                ;; offset=0x0061
       add      rsp, 8
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x006C
       mov      eax, esi
       sar      eax, 6
       lea      edx, [r15-0x01]
       sar      edx, 6
       mov      rcx, -1
       shlx     rcx, rcx, rsi
       and      r15d, 63
       je       SHORT G_M000_IG07
       mov      edi, 1
       shlx     rdi, rdi, r15
       dec      rdi
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x009C
       mov      rdi, -1
 
G_M000_IG08:                ;; offset=0x00A6
       cmp      eax, edx
       jne      SHORT G_M000_IG09
       mov      esi, dword ptr [r14+0x08]
       cmp      eax, esi
       jae      SHORT G_M000_IG16
       mov      esi, eax
       and      rcx, qword ptr [r14+8*rsi+0x10]
       test     rcx, rdi
       setne    cl
       movzx    rcx, cl
       jmp      SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x00C4
       mov      rsi, r14
       mov      r8d, dword ptr [rsi+0x08]
       cmp      eax, r8d
       jae      SHORT G_M000_IG16
       mov      r9d, eax
       test     qword ptr [rsi+8*r9+0x10], rcx
       jne      SHORT G_M000_IG14
       inc      eax
       cmp      eax, edx
       jge      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E0
       mov      rcx, r14
       cmp      eax, r8d
       jae      SHORT G_M000_IG16
       mov      esi, eax
       cmp      qword ptr [rcx+8*rsi+0x10], 0
       jne      SHORT G_M000_IG14
       inc      eax
       cmp      eax, edx
       jl       SHORT G_M000_IG10
 
G_M000_IG11:                ;; offset=0x00F8
       mov      rax, r14
       cmp      edx, r8d
       jae      SHORT G_M000_IG16
       mov      ecx, edx
       test     qword ptr [rax+8*rcx+0x10], rdi
       setne    cl
       movzx    rcx, cl
 
G_M000_IG12:                ;; offset=0x010D
       movzx    rax, cl
 
G_M000_IG13:                ;; offset=0x0110
       add      rsp, 8
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x011B
       mov      eax, 1
 
G_M000_IG15:                ;; offset=0x0120
       add      rsp, 8
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG16:                ;; offset=0x012B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 305

; Assembly listing for method GameplayTags.FrozenGameplayTagQuery:MatchesDirect(GameplayTags.Experiments.DirectArraySet):bool:this (FullOpts)
; Emitting BLENDED_CODE for X64 with AVX512 - Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 2 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       push     rax
       lea      rbp, [rsp+0x10]
 
G_M000_IG02:                ;; offset=0x0008
       test     rsi, rsi
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x000D
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x000F
       add      rsp, 8
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x0016
       mov      rdx, gword ptr [rdi+0x20]
       mov      rax, gword ptr [rsi+0x18]
       cmp      byte  ptr [rdx], dl
       cmp      rdx, rax
       jne      SHORT G_M000_IG09
       mov      rdx, gword ptr [rdi+0x08]
       cmp      dword ptr [rdx+0x08], 0
       je       SHORT G_M000_IG07
       mov      rdx, rsi
       xor      esi, esi
 
G_M000_IG06:                ;; offset=0x0034
       add      rsp, 8
       pop      rbx
       pop      rbp
       tail.jmp [GameplayTags.FrozenGameplayTagQuery:EvaluateDirect(int,GameplayTags.Experiments.DirectArraySet):bool:this]
 
G_M000_IG07:                ;; offset=0x0040
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x0042
       add      rsp, 8
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x0049
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 132

; Assembly listing for method GameplayTags.FrozenGameplayTagQuery:EvaluateDirect(int,GameplayTags.Experiments.DirectArraySet):bool:this (FullOpts)
; Emitting BLENDED_CODE for X64 with AVX512 - Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 0 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       push     rax
       lea      rbp, [rsp+0x30]
       mov      rbx, rdi
       mov      r15, rdx
 
G_M000_IG02:                ;; offset=0x0016
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG30
       mov      esi, esi
       lea      rsi, [rsi+2*rsi]
       lea      rdi, bword ptr [rdi+4*rsi+0x10]
       mov      r14d, dword ptr [rdi]
       mov      r13d, dword ptr [rdi+0x04]
       mov      r12d, dword ptr [rdi+0x08]
       add      r12d, r13d
       lea      edi, [r14-0x01]
       cmp      edi, 4
       ja       G_M000_IG24
       lea      rsi, [reloc @RWD00]
       mov      esi, dword ptr [rsi+4*rdi]
       lea      rdx, G_M000_IG02
       add      rsi, rdx
       jmp      rsi
 
G_M000_IG03:                ;; offset=0x005F
       cmp      r13d, r12d
       jge      G_M000_IG20
 
G_M000_IG04:                ;; offset=0x0068
       mov      rdi, gword ptr [rbx+0x18]
       mov      rsi, rdi
       mov      edx, dword ptr [rsi+0x08]
       cmp      r13d, edx
       jae      G_M000_IG30
       mov      edx, r13d
       mov      esi, dword ptr [rsi+8*rdx+0x10]
       mov      edx, r13d
       mov      edx, dword ptr [rdi+8*rdx+0x14]
       cmp      dword ptr [r15+0x28], 0
       je       G_M000_IG22
 
G_M000_IG05:                ;; offset=0x0094
       cmp      esi, edx
       je       G_M000_IG22
       mov      rdi, gword ptr [r15+0x10]
       test     rdi, rdi
       jne      SHORT G_M000_IG06
       mov      rdi, r15
       call     [GameplayTags.Experiments.DirectArraySet:AnyInMicroRange(int,int):bool:this]
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00B0
       call     [GameplayTags.Experiments.DirectArraySet:AnyInDenseRange(ulong[],int,int):bool]
 
G_M000_IG07:                ;; offset=0x00B6
       test     eax, eax
       je       G_M000_IG22
 
G_M000_IG08:                ;; offset=0x00BE
       inc      r13d
       cmp      r13d, r12d
       jl       SHORT G_M000_IG04
 
G_M000_IG09:                ;; offset=0x00C6
       jmp      G_M000_IG20
 
G_M000_IG10:                ;; offset=0x00CB
       cmp      r13d, r12d
       jge      SHORT G_M000_IG16
 
G_M000_IG11:                ;; offset=0x00D0
       mov      rdi, gword ptr [rbx+0x18]
       mov      rsi, rdi
       mov      edx, dword ptr [rsi+0x08]
       cmp      r13d, edx
       jae      G_M000_IG30
       mov      edx, r13d
       mov      esi, dword ptr [rsi+8*rdx+0x10]
       mov      edx, r13d
       mov      edx, dword ptr [rdi+8*rdx+0x14]
       cmp      dword ptr [r15+0x28], 0
       je       SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x00F8
       cmp      esi, edx
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [r15+0x10]
       test     rdi, rdi
       jne      SHORT G_M000_IG13
       mov      rdi, r15
       call     [GameplayTags.Experiments.DirectArraySet:AnyInMicroRange(int,int):bool:this]
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0110
       call     [GameplayTags.Experiments.DirectArraySet:AnyInDenseRange(ulong[],int,int):bool]
 
G_M000_IG14:                ;; offset=0x0116
       test     eax, eax
       jne      SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x011A
       inc      r13d
       cmp      r13d, r12d
       jl       SHORT G_M000_IG11
 
G_M000_IG16:                ;; offset=0x0122
       xor      r13d, r13d
       cmp      r14d, 3
       sete     r13b
       jmp      G_M000_IG28
 
G_M000_IG17:                ;; offset=0x0132
       xor      r13d, r13d
       cmp      r14d, 1
       sete     r13b
       jmp      G_M000_IG28
 
G_M000_IG18:                ;; offset=0x0142
       cmp      r13d, r12d
       jge      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0147
       mov      rdi, rbx
       mov      rdi, gword ptr [rdi+0x10]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG30
       mov      esi, r13d
       mov      esi, dword ptr [rdi+4*rsi+0x10]
       mov      rdi, rbx
       mov      rdx, r15
       call     [GameplayTags.FrozenGameplayTagQuery:EvaluateDirect(int,GameplayTags.Experiments.DirectArraySet):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG22
       inc      r13d
       cmp      r13d, r12d
       jl       SHORT G_M000_IG19
 
G_M000_IG20:                ;; offset=0x0177
       mov      eax, 1
 
G_M000_IG21:                ;; offset=0x017C
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG22:                ;; offset=0x018B
       xor      eax, eax
 
G_M000_IG23:                ;; offset=0x018D
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x019C
       cmp      r13d, r12d
       jge      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x01A1
       mov      rdi, rbx
       mov      rdi, gword ptr [rdi+0x10]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      SHORT G_M000_IG30
       mov      esi, r13d
       mov      esi, dword ptr [rdi+4*rsi+0x10]
       mov      rdi, rbx
       mov      rdx, r15
       call     [GameplayTags.FrozenGameplayTagQuery:EvaluateDirect(int,GameplayTags.Experiments.DirectArraySet):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG27
       inc      r13d
       cmp      r13d, r12d
       jl       SHORT G_M000_IG25
 
G_M000_IG26:                ;; offset=0x01CD
       xor      r13d, r13d
       cmp      r14d, 6
       sete     r13b
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x01DA
       xor      r13d, r13d
       cmp      r14d, 4
       sete     r13b
 
G_M000_IG28:                ;; offset=0x01E5
       movzx    rax, r13b
 
G_M000_IG29:                ;; offset=0x01E9
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG30:                ;; offset=0x01F8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000000B5h ; case G_M000_IG10
       	dd	00000049h ; case G_M000_IG03
       	dd	000000B5h ; case G_M000_IG10
       	dd	00000186h ; case G_M000_IG24
       	dd	0000012Ch ; case G_M000_IG18

; Total bytes of code 510

; Assembly listing for method GameplayTags.Experiments.DirectArraySet:AnyInDenseRange(ulong[],int,int):bool (FullOpts)
; Emitting BLENDED_CODE for X64 with AVX512 - Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       mov      rbp, rsp
 
G_M000_IG02:                ;; offset=0x0004
       mov      ecx, esi
       sar      ecx, 6
       lea      r8d, [rdx-0x01]
       sar      r8d, 6
       mov      rax, -1
       shlx     rsi, rax, rsi
       test     dl, 63
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0025
       mov      eax, 1
       shlx     rdx, rax, rdx
       dec      rdx
       jmp      SHORT G_M000_IG05
       align    [0 bytes for IG11]
 
G_M000_IG04:                ;; offset=0x0034
       mov      rdx, -1
 
G_M000_IG05:                ;; offset=0x003E
       cmp      ecx, r8d
       jne      SHORT G_M000_IG08
 
G_M000_IG06:                ;; offset=0x0043
       mov      r9d, dword ptr [rdi+0x08]
       cmp      ecx, r9d
       jae      G_M000_IG18
       mov      eax, ecx
       and      rsi, qword ptr [rdi+8*rax+0x10]
       xor      eax, eax
       test     rsi, rdx
       setne    al
 
G_M000_IG07:                ;; offset=0x005F
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0061
       mov      r9d, dword ptr [rdi+0x08]
       cmp      ecx, r9d
       jae      SHORT G_M000_IG18
       mov      eax, ecx
       test     qword ptr [rdi+8*rax+0x10], rsi
       je       SHORT G_M000_IG10
       mov      eax, 1
 
G_M000_IG09:                ;; offset=0x0078
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x007A
       inc      ecx
       cmp      ecx, r8d
       jge      SHORT G_M000_IG14
       mov      eax, ecx
       or       eax, r8d
       jl       SHORT G_M000_IG13
       cmp      r9d, r8d
       jl       SHORT G_M000_IG13
 
G_M000_IG11:                ;; offset=0x008D
       mov      eax, ecx
       cmp      qword ptr [rdi+8*rax+0x10], 0
       jne      SHORT G_M000_IG16
       inc      ecx
       cmp      ecx, r8d
       jl       SHORT G_M000_IG11
 
G_M000_IG12:                ;; offset=0x009E
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x00A0
       cmp      ecx, r9d
       jae      SHORT G_M000_IG18
       mov      eax, ecx
       cmp      qword ptr [rdi+8*rax+0x10], 0
       jne      SHORT G_M000_IG16
       inc      ecx
       cmp      ecx, r8d
       jl       SHORT G_M000_IG13
 
G_M000_IG14:                ;; offset=0x00B6
       cmp      r8d, r9d
       jae      SHORT G_M000_IG18
       mov      eax, r8d
       test     qword ptr [rdi+8*rax+0x10], rdx
       setne    al
       movzx    rax, al
 
G_M000_IG15:                ;; offset=0x00C9
       pop      rbp
       ret      
 
G_M000_IG16:                ;; offset=0x00CB
       mov      eax, 1
 
G_M000_IG17:                ;; offset=0x00D0
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x00D2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 216

; Assembly listing for method BridgeProbe:Work(int):long (FullOpts)
; Emitting BLENDED_CODE for X64 with AVX512 - Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 15 single block inlinees; 24 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       push     rax
       lea      rbp, [rsp+0x30]
       mov      ebx, edi
 
G_M000_IG02:                ;; offset=0x0012
       xor      r15d, r15d
       cmp      byte  ptr [(reloc 0x7f16759345ac)], 0
       je       G_M000_IG29
 
G_M000_IG03:                ;; offset=0x0022
       cmp      byte  ptr [(reloc 0x7f16759345ad)], 0
       je       G_M000_IG19
       xor      r14d, r14d
       test     ebx, ebx
       jle      G_M000_IG17
 
G_M000_IG04:                ;; offset=0x003A
       mov      rsi, 0x7ED668001CC8
       mov      r13, gword ptr [rsi]
       mov      rsi, gword ptr [r13+0x08]
       mov      rdx, qword ptr [r13+0x10]
       mov      r12, 0x7ED668001CE0
       mov      rdi, gword ptr [r12]
       cmp      dword ptr [rdi], edi
       call     [GameplayTags.Experiments.DirectArraySet:RemoveTag(GameplayTags.RuntimeTag):bool:this]
       mov      rdx, gword ptr [r12]
       mov      rdi, 0x7ED668001CE8
       mov      rdi, gword ptr [rdi]
       cmp      byte  ptr [rdx], dl
       test     rdi, rdi
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x007D
       mov      rsi, gword ptr [rdi+0x20]
       mov      rax, gword ptr [rdx+0x18]
       cmp      byte  ptr [rsi], sil
       cmp      rsi, rax
       jne      G_M000_IG51
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0x08], 0
       je       SHORT G_M000_IG06
       xor      esi, esi
       call     [GameplayTags.FrozenGameplayTagQuery:EvaluateDirect(int,GameplayTags.Experiments.DirectArraySet):bool:this]
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00A5
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x00A7
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00A9
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x00AB
       xor      edi, edi
       test     eax, eax
       setne    dil
       mov      edi, edi
       add      r15, rdi
       mov      rdi, gword ptr [r12]
       mov      rsi, gword ptr [r13+0x08]
       mov      eax, dword ptr [r13+0x10]
       cmp      byte  ptr [rdi], dil
       test     rsi, rsi
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00CC
       mov      rcx, gword ptr [rdi+0x18]
       cmp      byte  ptr [rcx], cl
       cmp      rcx, rsi
       jne      G_M000_IG52
       mov      esi, eax
       call     [GameplayTags.Experiments.DirectArraySet:AddId(int):bool:this]
 
G_M000_IG11:                ;; offset=0x00E3
       mov      rdx, gword ptr [r12]
       mov      rdi, 0x7ED668001CE8
       mov      rdi, gword ptr [rdi]
       cmp      byte  ptr [rdx], dl
       test     rdi, rdi
       je       SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x00FB
       mov      rsi, gword ptr [rdi+0x20]
       mov      rax, gword ptr [rdx+0x18]
       cmp      byte  ptr [rsi], sil
       cmp      rsi, rax
       jne      G_M000_IG53
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0x08], 0
       je       SHORT G_M000_IG13
       xor      esi, esi
       call     [GameplayTags.FrozenGameplayTagQuery:EvaluateDirect(int,GameplayTags.Experiments.DirectArraySet):bool:this]
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0123
       xor      eax, eax
 
G_M000_IG14:                ;; offset=0x0125
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0127
       xor      eax, eax
 
G_M000_IG16:                ;; offset=0x0129
       test     eax, eax
       setne    al
       movzx    rax, al
       add      r15, rax
       inc      r14d
       cmp      r14d, ebx
       jl       G_M000_IG04
 
G_M000_IG17:                ;; offset=0x0140
       xor      qword ptr [(reloc 0x7f16759345a0)], r15
       mov      rax, r15
 
G_M000_IG18:                ;; offset=0x014A
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x0159
       xor      r14d, r14d
       test     ebx, ebx
       jle      SHORT G_M000_IG17
 
G_M000_IG20:                ;; offset=0x0160
       xor      r13d, r13d
 
G_M000_IG21:                ;; offset=0x0163
       mov      r12, 0x7ED668001CE0
       mov      rdx, gword ptr [r12]
       mov      rdi, 0x7ED668001CE8
       mov      rdi, gword ptr [rdi]
       cmp      byte  ptr [rdx], dl
       test     rdi, rdi
       je       SHORT G_M000_IG25
 
G_M000_IG22:                ;; offset=0x0185
       mov      rsi, gword ptr [rdi+0x20]
       mov      rax, gword ptr [rdx+0x18]
       cmp      byte  ptr [rsi], sil
       cmp      rsi, rax
       jne      G_M000_IG54
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0x08], 0
       je       SHORT G_M000_IG23
       xor      esi, esi
       call     [GameplayTags.FrozenGameplayTagQuery:EvaluateDirect(int,GameplayTags.Experiments.DirectArraySet):bool:this]
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x01AD
       xor      eax, eax
 
G_M000_IG24:                ;; offset=0x01AF
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x01B1
       xor      eax, eax
 
G_M000_IG26:                ;; offset=0x01B3
       xor      edi, edi
       test     eax, eax
       setne    dil
       mov      edi, edi
       add      r15, rdi
       inc      r13d
       cmp      r13d, 64
       jl       SHORT G_M000_IG21
 
G_M000_IG27:                ;; offset=0x01C9
       inc      r14d
       cmp      r14d, ebx
       jl       SHORT G_M000_IG20
 
G_M000_IG28:                ;; offset=0x01D1
       jmp      G_M000_IG17
 
G_M000_IG29:                ;; offset=0x01D6
       cmp      byte  ptr [(reloc 0x7f16759345ad)], 0
       je       G_M000_IG42
       xor      r14d, r14d
       test     ebx, ebx
       jle      G_M000_IG17
 
G_M000_IG30:                ;; offset=0x01EE
       mov      r13, 0x7ED668001CD8
       mov      rdi, gword ptr [r13]
       mov      rsi, 0x7ED668001CC8
       mov      rsi, gword ptr [rsi]
       mov      r12, rsi
       mov      rsi, r12
       mov      rax, gword ptr [rsi+0x08]
       mov      esi, dword ptr [rsi+0x10]
       cmp      byte  ptr [rdi], dil
       test     rax, rax
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x021E
       mov      rcx, gword ptr [rdi+0x18]
       cmp      byte  ptr [rcx], cl
       cmp      rcx, rax
       jne      G_M000_IG55
       call     [GameplayTags.RuntimeTagSet:RemoveId(int):bool:this]
 
G_M000_IG32:                ;; offset=0x0233
       mov      rdi, 0x7ED668001CE8
       mov      rdi, gword ptr [rdi]
       mov      rdx, gword ptr [r13]
       cmp      byte  ptr [rdi], dil
       test     rdx, rdx
       je       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x024C
       mov      rsi, gword ptr [rdi+0x20]
       mov      rax, gword ptr [rdx+0x18]
       cmp      byte  ptr [rsi], sil
       cmp      rsi, rax
       jne      G_M000_IG56
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0x08], 0
       je       SHORT G_M000_IG34
       xor      esi, esi
       call     [GameplayTags.FrozenGameplayTagQuery:Evaluate(int,GameplayTags.RuntimeTagSet):bool:this]
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0274
       xor      eax, eax
 
G_M000_IG35:                ;; offset=0x0276
       xor      edi, edi
       test     eax, eax
       setne    dil
       mov      edi, edi
       add      r15, rdi
       mov      rdi, gword ptr [r13]
       mov      rsi, r12
       mov      rax, gword ptr [rsi+0x08]
       mov      esi, dword ptr [rsi+0x10]
       cmp      byte  ptr [rdi], dil
       test     rax, rax
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0299
       mov      rcx, gword ptr [rdi+0x18]
       cmp      byte  ptr [rcx], cl
       cmp      rcx, rax
       jne      G_M000_IG57
       call     [GameplayTags.RuntimeTagSet:AddId(int):bool:this]
 
G_M000_IG37:                ;; offset=0x02AE
       mov      rdi, 0x7ED668001CE8
       mov      rdi, gword ptr [rdi]
       mov      rdx, gword ptr [r13]
       cmp      byte  ptr [rdi], dil
       test     rdx, rdx
       je       SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x02C7
       mov      rsi, gword ptr [rdi+0x20]
       mov      rax, gword ptr [rdx+0x18]
       cmp      byte  ptr [rsi], sil
       cmp      rsi, rax
       jne      G_M000_IG58
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0x08], 0
       je       SHORT G_M000_IG39
       xor      esi, esi
       call     [GameplayTags.FrozenGameplayTagQuery:Evaluate(int,GameplayTags.RuntimeTagSet):bool:this]
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x02EF
       xor      eax, eax
 
G_M000_IG40:                ;; offset=0x02F1
       xor      edi, edi
       test     eax, eax
       setne    dil
       mov      edi, edi
       add      r15, rdi
       inc      r14d
       cmp      r14d, ebx
       jl       G_M000_IG30
 
G_M000_IG41:                ;; offset=0x030A
       jmp      G_M000_IG17
 
G_M000_IG42:                ;; offset=0x030F
       xor      r14d, r14d
       test     ebx, ebx
       jle      G_M000_IG17
 
G_M000_IG43:                ;; offset=0x031A
       xor      r12d, r12d
 
G_M000_IG44:                ;; offset=0x031D
       mov      rdi, 0x7ED668001CE8
       mov      rdi, gword ptr [rdi]
       mov      r13, 0x7ED668001CD8
       mov      rdx, gword ptr [r13]
       cmp      byte  ptr [rdi], dil
       test     rdx, rdx
       je       SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x0340
       mov      rsi, gword ptr [rdi+0x20]
       mov      rax, gword ptr [rdx+0x18]
       cmp      byte  ptr [rsi], sil
       cmp      rsi, rax
       jne      SHORT G_M000_IG50
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0x08], 0
       je       SHORT G_M000_IG46
       xor      esi, esi
       call     [GameplayTags.FrozenGameplayTagQuery:Evaluate(int,GameplayTags.RuntimeTagSet):bool:this]
       jmp      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x0364
       xor      eax, eax
 
G_M000_IG47:                ;; offset=0x0366
       xor      edi, edi
       test     eax, eax
       setne    dil
       mov      edi, edi
       add      r15, rdi
       inc      r12d
       cmp      r12d, 64
       jl       SHORT G_M000_IG44
 
G_M000_IG48:                ;; offset=0x037C
       inc      r14d
       cmp      r14d, ebx
       jl       SHORT G_M000_IG43
 
G_M000_IG49:                ;; offset=0x0384
       jmp      G_M000_IG17
 
G_M000_IG50:                ;; offset=0x0389
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG51:                ;; offset=0x03C3
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG52:                ;; offset=0x03FD
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG53:                ;; offset=0x0437
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG54:                ;; offset=0x0471
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG55:                ;; offset=0x04AB
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG56:                ;; offset=0x04E5
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG57:                ;; offset=0x051F
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
 
G_M000_IG58:                ;; offset=0x0559
       mov      rdi, 0x7F16758DE2C8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xBA4
       mov      rsi, 0x7F1675936680
       call     CORINFO_HELP_STRCNS
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.ArgumentException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 1428

; Assembly listing for method System.Reflection.Emit.SignatureHelper:AddOneArgTypeHelperWorker(System.Type,bool):this (FullOpts)
; Emitting BLENDED_CODE for X64 with AVX512 - Unix
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 37 single block inlinees; 17 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       push     rax
       lea      rbp, [rsp+0x30]
       mov      rbx, rdi
       mov      r15, rsi
       mov      r14d, edx
 
G_M000_IG02:                ;; offset=0x0019
       mov      rdi, r15
       mov      r13, qword ptr [r15]
       mov      r12, qword ptr [r13+0x58]
       call     [r12+0x30]System.Type:get_IsGenericParameter():bool:this
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0030
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x50]
       call     [rax+0x38]System.Type:get_DeclaringMethod():System.Reflection.MethodBase:this
       test     rax, rax
       je       SHORT G_M000_IG05
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG04
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG04:                ;; offset=0x0064
       mov      rsi, gword ptr [rbx+0x08]
       mov      edi, dword ptr [rbx+0x18]
       lea      eax, [rdi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rsi+rdi+0x10], 30
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x0081
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG06
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG06:                ;; offset=0x00A6
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 19
 
G_M000_IG07:                ;; offset=0x00C1
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x70]
       call     [rax]System.Type:get_GenericParameterPosition():int:this
       mov      esi, eax
       mov      rdi, rbx
 
G_M000_IG08:                ;; offset=0x00CF
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddData(int):this]
 
G_M000_IG09:                ;; offset=0x00E3
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x60]
       mov      qword ptr [rbp-0x30], rax
       call     [rax+0x08]System.Type:get_IsGenericType():bool:this
       test     eax, eax
       je       G_M000_IG15
 
G_M000_IG10:                ;; offset=0x00F9
       mov      rdi, r15
       mov      rax, qword ptr [rbp-0x30]
       call     [rax+0x10]System.Type:get_IsGenericTypeDefinition():bool:this
       test     eax, eax
       je       SHORT G_M000_IG11
       test     r14b, r14b
       jne      G_M000_IG15
 
G_M000_IG11:                ;; offset=0x0110
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG12
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG12:                ;; offset=0x0135
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 21
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x18]System.Type:GetGenericTypeDefinition():System.Type:this
       mov      rsi, rax
       mov      rdi, rbx
       mov      edx, 1
       call     [System.Reflection.Emit.SignatureHelper:AddOneArgTypeHelperWorker(System.Type,bool):this]
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x28]System.Type:GetGenericArguments():System.Type[]:this
       mov      r15, rax
       mov      r13d, dword ptr [r15+0x08]
       mov      esi, r13d
       mov      rdi, rbx
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       xor      r12d, r12d
       test     r13d, r13d
       jle      G_M000_IG61
 
G_M000_IG13:                ;; offset=0x0194
       mov      esi, r12d
       mov      rsi, gword ptr [r15+8*rsi+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [System.Reflection.Emit.SignatureHelper:AddOneArgTypeHelperWorker(System.Type,bool):this]
       inc      r12d
       cmp      r13d, r12d
       jg       SHORT G_M000_IG13
 
G_M000_IG14:                ;; offset=0x01AF
       jmp      G_M000_IG61
 
G_M000_IG15:                ;; offset=0x01B4
       mov      r14, r15
       mov      rdi, 0x7F1676733940
       cmp      r13, rdi
       jne      G_M000_IG25
 
G_M000_IG16:                ;; offset=0x01CA
       mov      rdi, gword ptr [r14+0x10]
       mov      rsi, gword ptr [rbx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Reflection.Emit.RuntimeModuleBuilder:Equals(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG18
       cmp      byte  ptr [r14+0x9A], 0
       je       SHORT G_M000_IG17
       mov      rdi, r14
       call     [System.Reflection.Emit.RuntimeTypeBuilder:ThrowIfCreated():this]
 
G_M000_IG17:                ;; offset=0x01F1
       mov      r12d, dword ptr [r14+0x78]
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x01F7
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, r15
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x68]
       call     [rax+0x20]System.Reflection.Emit.ModuleBuilder:GetTypeMetadataToken(System.Type):int:this
       mov      r12d, eax
 
G_M000_IG19:                ;; offset=0x020B
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x78]
       call     [rax+0x08]System.Type:IsValueTypeImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG20
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG20:                ;; offset=0x023E
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 17
       mov      rdi, rbx
       mov      esi, r12d
 
G_M000_IG21:                ;; offset=0x025F
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG22:                ;; offset=0x0273
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG23
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG23:                ;; offset=0x0298
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 18
       mov      rdi, rbx
       mov      esi, r12d
 
G_M000_IG24:                ;; offset=0x02B9
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG25:                ;; offset=0x02CD
       mov      rdi, r15
       mov      rsi, 0x7F1676734580
       cmp      r13, rsi
       jne      G_M000_IG35
 
G_M000_IG26:                ;; offset=0x02E3
       mov      r12, gword ptr [rdi+0x08]
       mov      rdi, gword ptr [r12+0x10]
       mov      rsi, gword ptr [rbx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Reflection.Emit.RuntimeModuleBuilder:Equals(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG28
       cmp      byte  ptr [r12+0x9A], 0
       je       SHORT G_M000_IG27
       mov      rdi, r12
       call     [System.Reflection.Emit.RuntimeTypeBuilder:ThrowIfCreated():this]
 
G_M000_IG27:                ;; offset=0x0310
       mov      r14d, dword ptr [r12+0x78]
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0317
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, r15
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x68]
       call     [rax+0x20]System.Reflection.Emit.ModuleBuilder:GetTypeMetadataToken(System.Type):int:this
       mov      r14d, eax
 
G_M000_IG29:                ;; offset=0x032B
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x78]
       call     [rax+0x08]System.Type:IsValueTypeImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG32
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG30
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG30:                ;; offset=0x035E
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 17
       mov      rdi, rbx
       mov      esi, r14d
 
G_M000_IG31:                ;; offset=0x037F
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG32:                ;; offset=0x0393
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG33
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG33:                ;; offset=0x03B8
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 18
       mov      rdi, rbx
       mov      esi, r14d
 
G_M000_IG34:                ;; offset=0x03D9
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG35:                ;; offset=0x03ED
       mov      rdi, r15
       call     [r12+0x18]System.Type:IsByRefImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG39
 
G_M000_IG36:                ;; offset=0x03F9
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG37
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG37:                ;; offset=0x041E
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 16
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x08]System.Type:GetElementType():System.Type:this
       mov      r15, rax
 
G_M000_IG38:                ;; offset=0x0446
       xor      r14d, r14d
       jmp      G_M000_IG02
 
G_M000_IG39:                ;; offset=0x044E
       mov      rdi, r15
       call     [r12+0x20]System.Type:IsPointerImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG42
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0468
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG41:                ;; offset=0x0483
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 15
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x08]System.Type:GetElementType():System.Type:this
       mov      r15, rax
       jmp      SHORT G_M000_IG38
 
G_M000_IG42:                ;; offset=0x04AD
       mov      rdi, r15
       call     [r12+0x10]System.Type:IsArrayImpl():bool:this
       test     eax, eax
       je       G_M000_IG49
       mov      rdi, r15
       mov      r14, qword ptr [rbp-0x30]
       call     [r14+0x18]System.Type:get_IsSZArray():bool:this
       test     eax, eax
       je       SHORT G_M000_IG45
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x04DA
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG44:                ;; offset=0x04F5
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 29
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x08]System.Type:GetElementType():System.Type:this
       mov      r15, rax
       jmp      G_M000_IG38
 
G_M000_IG45:                ;; offset=0x0522
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG46
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG46:                ;; offset=0x054B
       mov      rdi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x18]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbx+0x18], ecx
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rax+0x10], 20
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x08]System.Type:GetElementType():System.Type:this
       mov      rsi, rax
       mov      rdi, rbx
       xor      edx, edx
       call     [System.Reflection.Emit.SignatureHelper:AddOneArgTypeHelperWorker(System.Type,bool):this]
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x68]
       call     [rax+0x10]System.Type:GetArrayRank():int:this
       mov      r13d, eax
       mov      rdi, rbx
       mov      esi, r13d
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       mov      rdi, rbx
       xor      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       mov      rdi, rbx
       mov      esi, r13d
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       xor      r15d, r15d
       test     r13d, r13d
       jle      G_M000_IG61
 
G_M000_IG47:                ;; offset=0x05BA
       mov      rdi, rbx
       xor      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:AddData(int):this]
       inc      r15d
       cmp      r15d, r13d
       jl       SHORT G_M000_IG47
 
G_M000_IG48:                ;; offset=0x05CD
       jmp      G_M000_IG61
 
G_M000_IG49:                ;; offset=0x05D2
       mov      r14d, 34
       mov      rdi, 0x7F1675769C70
       cmp      r13, rdi
       jne      SHORT G_M000_IG51
       mov      rdi, r15
       call     System.RuntimeTypeHandle:GetCorElementType(System.RuntimeType):ubyte
       mov      r14d, eax
       cmp      r14d, 18
       jne      SHORT G_M000_IG51
       mov      rdi, 0x7F16F04008D0
       cmp      r15, rdi
       jne      SHORT G_M000_IG50
       mov      r14d, 28
       jmp      SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x060F
       mov      rdi, 0x7F16F0400020
       mov      eax, 14
       cmp      r15, rdi
       cmove    r14d, eax
 
G_M000_IG51:                ;; offset=0x0625
       mov      edi, r14d
       call     [System.Reflection.Emit.SignatureHelper:IsSimpleType(ubyte):bool]
       test     eax, eax
       je       SHORT G_M000_IG53
       mov      rdi, rbx
       mov      esi, r14d
 
G_M000_IG52:                ;; offset=0x0638
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddElementType(ubyte):this]
 
G_M000_IG53:                ;; offset=0x064C
       cmp      gword ptr [rbx+0x10], 0
       jne      SHORT G_M000_IG55
       mov      rdi, rbx
       mov      rsi, r15
 
G_M000_IG54:                ;; offset=0x0659
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:InternalAddRuntimeType(System.Type):this]
 
G_M000_IG55:                ;; offset=0x066D
       mov      rdi, r15
       mov      rax, qword ptr [r13+0x78]
       call     [rax+0x08]System.Type:IsValueTypeImpl():bool:this
       test     eax, eax
       je       SHORT G_M000_IG58
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, r15
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x68]
       call     [rax+0x20]System.Reflection.Emit.ModuleBuilder:GetTypeMetadataToken(System.Type):int:this
       mov      r15d, eax
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG56
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG56:                ;; offset=0x06B4
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 17
       mov      rdi, rbx
       mov      esi, r15d
 
G_M000_IG57:                ;; offset=0x06D5
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG58:                ;; offset=0x06E9
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, r15
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x68]
       call     [rax+0x20]System.Reflection.Emit.ModuleBuilder:GetTypeMetadataToken(System.Type):int:this
       mov      r15d, eax
       mov      esi, dword ptr [rbx+0x18]
       inc      esi
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jle      SHORT G_M000_IG59
       mov      esi, dword ptr [rdi+0x08]
       add      esi, esi
       call     [System.Reflection.Emit.SignatureHelper:ExpandArray(ubyte[],int):ubyte[]]
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG59:                ;; offset=0x0722
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x18]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbx+0x18], eax
       cmp      esi, dword ptr [rdi+0x08]
       jae      SHORT G_M000_IG62
       mov      byte  ptr [rdi+rsi+0x10], 18
       mov      rdi, rbx
       mov      esi, r15d
 
G_M000_IG60:                ;; offset=0x073F
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [System.Reflection.Emit.SignatureHelper:AddToken(int):this]
 
G_M000_IG61:                ;; offset=0x0753
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG62:                ;; offset=0x0762
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1896

