# v3 hardware-gated count helper factor

Candidate Runtime SHA256:546555352be5e6142b98b84648a55518c75c89af8c5d11e703cd8ea54bc058b8. It uses BitOperations only when a supported hardware backend is present and preserves the original inline SWAR otherwise. Exact-source normal, checked and actual checked Standard correctness gates passed before timing.

This is a targeted 18-cell admission diagnostic, not a replacement for the preserved full f98c4538 cohort. It includes all 10 prior nohw mixed regressions,3 representative hardware wins,3 unchanged mixed/empty controls, Dense sorted4096 and a tiny query control. Each backend uses three rounds with baseline A/A bracketing both v2 and v3, seven samples, fixed shared calibration and the original 64 MiB / 1 ms rules. Every cell is valid; prepared calls remain0B. Minimum actual samples are 1.97 ms nohw and 2.23 ms default.

| Comparison | Backend | Median wins | Regressions | Uncertain/small |
|---|---|---:|---:|---:|
|v3 / PR26 baseline|default|8|0|10|
|v3 / v2|default|0|0|18|
|v3 / PR26 baseline|nohw|0|0|18|
|v3 / v2|nohw|4|4|10|

Native nohw AppendCore now has no SoftwareFallback call and its entire normalized instruction text matches PR26 baseline (1737 bytes). v2 emitted a non-inlined ulong software fallback and 1657 bytes. Normalization removes only comments/blank lines and12-digit process addresses; arithmetic constants, labels, offsets and instruction order remain.

The Dense-path change is measurable in the targeted context: for Dense regular-scatter4096 mixed restore+remove, v2/baseline is1.158 and v3/baseline1.007, with v3/v2=0.869. Other Dense mixed rows also improve relative to v2, though not every cell passes the strict six-crossing gate versus baseline.

The large Micro/Auto skew-append losses do not persist consistently across contexts. In the targeted nohw cohort, v2/baseline is0.675 for Micro and0.664 for Auto, whereas v3/baseline is1.012/0.982. v3 is consequently about 50% slower than v2 in those cells in this context, while having no clear regression versus PR26. This does not support claiming the historical50% broad-context loss was algorithmically fixed or that v2’s targeted gain is universal. All contradictory-context observations remain visible.

Admission recommendation: retain v3 for eliminating the actual fallback call and preserving the targeted hardware gains, with explicit limits on broader performance claims. No extra tail-copy algorithm branch is supported by a persistent skew-append loss in this gate. Source and timing are tied to the exact v3 DLL above; later bridge changes require their own focused evidence.
